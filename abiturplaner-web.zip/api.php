<?php

declare(strict_types=1);

/**
 * Abiturplaner – Server-API (PHP + SQLite)
 *
 * Benutzer, Sitzungen und Noten liegen AUSSERHALB des Webroots
 * (Standard: /var/lib/abiturplaner, änderbar über die Umgebungsvariable ABI_DATA_DIR).
 * So überschreibt der Git-Updater niemals Daten.
 *
 * Endpunkte (api.php?a=...):
 *   GET  config   -> {register: bool}
 *   GET  me       -> {user}            (401, wenn nicht angemeldet)
 *   GET  load     -> {data, version}
 *   POST login    {username, password}
 *   POST register {username, password, invite}
 *   POST logout
 *   POST save     {data, version}      (409 bei Versionskonflikt)
 *   POST passwd   {old, new}
 */

const ABI_SESSION_DAYS = 30;
const ABI_MAX_BYTES = 1000000;
const ABI_MAX_FAILS = 8;     // Fehlversuche pro 15 Minuten (je IP bzw. je Benutzername)
const ABI_MIN_PW = 10;

// ---------------------------------------------------------------- Grundlagen
function abi_len(string $s): int {
	return function_exists('mb_strlen') ? mb_strlen($s) : strlen($s);
}

function abi_dir(): string {
	return rtrim(getenv('ABI_DATA_DIR') ?: '/var/lib/abiturplaner', '/');
}

function abi_config(): array {
	static $cfg = null;
	if ($cfg === null) {
		$cfg = ['allow_register' => false, 'invite_code' => '', 'trust_proxy' => false];
		$f = abi_dir() . '/config.php';
		if (is_file($f)) {
			$c = require $f;
			if (is_array($c)) {
				$cfg = array_merge($cfg, $c);
			}
		}
	}
	return $cfg;
}

function abi_db(): PDO {
	static $pdo = null;
	if ($pdo !== null) {
		return $pdo;
	}
	if (!extension_loaded('pdo_sqlite')) {
		throw new RuntimeException('PHP-Erweiterung pdo_sqlite fehlt (apt install php-sqlite3)');
	}
	$dir = abi_dir();
	if (!is_dir($dir) || !is_writable($dir)) {
		throw new RuntimeException("Datenverzeichnis fehlt oder ist nicht beschreibbar: $dir");
	}
	umask(0027);
	$pdo = new PDO('sqlite:' . $dir . '/abiturplaner.sqlite', null, null, [
		PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
		PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
	]);
	$pdo->exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
	$pdo->exec('
		CREATE TABLE IF NOT EXISTS users (
			id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, pass TEXT NOT NULL, created_at INTEGER NOT NULL);
		CREATE TABLE IF NOT EXISTS sessions (
			token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires_at INTEGER NOT NULL);
		CREATE TABLE IF NOT EXISTS docs (
			user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, json TEXT NOT NULL, version INTEGER NOT NULL, updated_at INTEGER NOT NULL);
		CREATE TABLE IF NOT EXISTS attempts (
			id INTEGER PRIMARY KEY, k TEXT NOT NULL, ts INTEGER NOT NULL);
		CREATE INDEX IF NOT EXISTS attempts_k ON attempts (k, ts);
	');
	return $pdo;
}

function abi_out(int $code, array $data): void {
	http_response_code($code);
	header('Content-Type: application/json; charset=utf-8');
	header('Cache-Control: no-store');
	header('X-Content-Type-Options: nosniff');
	echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
	exit;
}

function abi_ip(): string {
	$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
	if (abi_config()['trust_proxy'] && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		$ip = trim(explode(',', (string)$_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
	}
	return $ip;
}

function abi_https(): bool {
	if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
		return true;
	}
	return (bool)abi_config()['trust_proxy'] && ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
}

function abi_cookie_path(): string {
	return rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/') . '/';
}

function abi_set_cookie(string $value, int $expires): void {
	setcookie('abi_token', $value, [
		'expires' => $expires,
		'path' => abi_cookie_path(),
		'secure' => abi_https(),
		'httponly' => true,
		'samesite' => 'Lax',
	]);
}

// ---------------------------------------------------------------- Benutzer
function abi_norm_user(string $u): string {
	return strtolower(trim($u));
}

function abi_valid_user(string $u): bool {
	return (bool)preg_match('/^[a-z0-9._-]{3,32}$/', $u);
}

/** Legt einen Benutzer an und gibt die ID zurück (wirft Exception bei Fehlern). */
function abi_create_user(string $name, string $password): int {
	$name = abi_norm_user($name);
	if (!abi_valid_user($name)) {
		throw new InvalidArgumentException('Benutzername: 3–32 Zeichen aus a-z, 0-9, Punkt, Unterstrich, Minus');
	}
	if (abi_len($password) < ABI_MIN_PW) {
		throw new InvalidArgumentException('Passwort muss mindestens ' . ABI_MIN_PW . ' Zeichen lang sein');
	}
	$db = abi_db();
	$st = $db->prepare('SELECT 1 FROM users WHERE username = ?');
	$st->execute([$name]);
	if ($st->fetch()) {
		throw new InvalidArgumentException('Benutzername ist bereits vergeben');
	}
	$db->prepare('INSERT INTO users (username, pass, created_at) VALUES (?, ?, ?)')
		->execute([$name, password_hash($password, PASSWORD_DEFAULT), time()]);
	return (int)$db->lastInsertId();
}

function abi_current_user(): ?array {
	$t = $_COOKIE['abi_token'] ?? '';
	if (!is_string($t) || !preg_match('/^[a-f0-9]{64}$/', $t)) {
		return null;
	}
	$st = abi_db()->prepare('SELECT u.id, u.username FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > ?');
	$st->execute([hash('sha256', $t), time()]);
	return $st->fetch() ?: null;
}

function abi_start_session(int $userId): void {
	$db = abi_db();
	$db->prepare('DELETE FROM sessions WHERE expires_at < ?')->execute([time()]);
	$db->prepare('DELETE FROM attempts WHERE ts < ?')->execute([time() - 3600]);
	$token = bin2hex(random_bytes(32));
	$exp = time() + ABI_SESSION_DAYS * 86400;
	$db->prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)')
		->execute([hash('sha256', $token), $userId, $exp]);
	abi_set_cookie($token, $exp);
}

function abi_throttled(array $keys): bool {
	$db = abi_db();
	$st = $db->prepare('SELECT COUNT(*) FROM attempts WHERE k = ? AND ts > ?');
	foreach ($keys as $k) {
		$st->execute([$k, time() - 900]);
		if ((int)$st->fetchColumn() >= ABI_MAX_FAILS) {
			return true;
		}
	}
	return false;
}

function abi_fail(array $keys): void {
	$st = abi_db()->prepare('INSERT INTO attempts (k, ts) VALUES (?, ?)');
	foreach ($keys as $k) {
		$st->execute([$k, time()]);
	}
}

// ---------------------------------------------------------------- Anfrage
function abi_body(): array {
	$raw = (string)file_get_contents('php://input', false, null, 0, ABI_MAX_BYTES + 1024);
	if (strlen($raw) > ABI_MAX_BYTES + 512) {
		abi_out(413, ['error' => 'Daten zu groß']);
	}
	$j = json_decode($raw, true);
	return is_array($j) ? $j : [];
}

function abi_handle(): void {
	header('X-Content-Type-Options: nosniff');
	$a = (string)($_GET['a'] ?? '');
	$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
	$get = ['config', 'me', 'load'];
	$post = ['login', 'register', 'logout', 'save', 'passwd'];
	if (!in_array($a, array_merge($get, $post), true)) {
		abi_out(404, ['error' => 'Unbekannte Aktion']);
	}
	if (in_array($a, $post, true)) {
		if ($method !== 'POST') {
			abi_out(405, ['error' => 'POST erforderlich']);
		}
		// CSRF-Schutz: benutzerdefinierter Header löst im Browser eine CORS-Prüfung aus, die wir nie erlauben.
		if (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'abiturplaner') {
			abi_out(403, ['error' => 'Ungültige Anfrage']);
		}
	} elseif ($method !== 'GET') {
		abi_out(405, ['error' => 'GET erforderlich']);
	}

	try {
		if ($a === 'config') {
			abi_out(200, ['register' => (bool)abi_config()['allow_register'] && (string)abi_config()['invite_code'] !== '']);
		}
		$db = abi_db();
		$ip = abi_ip();

		if ($a === 'login') {
			$b = abi_body();
			$name = abi_norm_user((string)($b['username'] ?? ''));
			$pw = (string)($b['password'] ?? '');
			$keys = ['ip:' . $ip, 'u:' . $name];
			if (abi_throttled($keys)) {
				abi_out(429, ['error' => 'Zu viele Fehlversuche. Bitte in 15 Minuten erneut versuchen.']);
			}
			$st = $db->prepare('SELECT id, pass FROM users WHERE username = ?');
			$st->execute([$name]);
			$u = $st->fetch();
			// Bei unbekanntem Benutzer trotzdem hashen (gleiche Antwortzeit)
			$ok = password_verify($pw, $u ? $u['pass'] : '$2y$10$ToBrc9DJcpQZRGGAUlcBuO4PbqXDLGe.EVnrw6O0YZib48pbOSLiK');
			if (!$u || !$ok) {
				abi_fail($keys);
				abi_out(401, ['error' => 'Benutzername oder Passwort falsch']);
			}
			if (password_needs_rehash($u['pass'], PASSWORD_DEFAULT)) {
				$db->prepare('UPDATE users SET pass = ? WHERE id = ?')->execute([password_hash($pw, PASSWORD_DEFAULT), $u['id']]);
			}
			abi_start_session((int)$u['id']);
			abi_out(200, ['user' => $name]);
		}

		if ($a === 'register') {
			$cfg = abi_config();
			if (!$cfg['allow_register'] || (string)$cfg['invite_code'] === '') {
				abi_out(403, ['error' => 'Registrierung ist deaktiviert']);
			}
			$b = abi_body();
			$keys = ['reg:' . $ip];
			if (abi_throttled($keys)) {
				abi_out(429, ['error' => 'Zu viele Versuche. Bitte später erneut versuchen.']);
			}
			if (!hash_equals((string)$cfg['invite_code'], (string)($b['invite'] ?? ''))) {
				abi_fail($keys);
				abi_out(403, ['error' => 'Einladungscode falsch']);
			}
			try {
				$id = abi_create_user((string)($b['username'] ?? ''), (string)($b['password'] ?? ''));
			} catch (InvalidArgumentException $e) {
				abi_out(400, ['error' => $e->getMessage()]);
			}
			abi_start_session($id);
			abi_out(200, ['user' => abi_norm_user((string)$b['username'])]);
		}

		$user = abi_current_user();
		if (!$user) {
			abi_out(401, ['error' => 'Nicht angemeldet']);
		}
		$uid = (int)$user['id'];

		switch ($a) {
		case 'me':
			abi_out(200, ['user' => $user['username']]);
			break;

		case 'logout':
			$t = (string)($_COOKIE['abi_token'] ?? '');
			$db->prepare('DELETE FROM sessions WHERE token_hash = ?')->execute([hash('sha256', $t)]);
			abi_set_cookie('', time() - 3600);
			abi_out(200, ['ok' => true]);
			break;

		case 'load':
			$st = $db->prepare('SELECT json, version FROM docs WHERE user_id = ?');
			$st->execute([$uid]);
			$row = $st->fetch();
			abi_out(200, $row ? ['data' => json_decode($row['json'], true), 'version' => (int)$row['version']] : ['data' => null, 'version' => 0]);
			break;

		case 'save':
			$b = abi_body();
			$data = $b['data'] ?? null;
			if (!is_array($data) || !isset($data['fachs']) || !is_array($data['fachs']) || count($data['fachs']) > 60) {
				abi_out(400, ['error' => 'Ungültige Daten']);
			}
			$json = json_encode($data, JSON_UNESCAPED_UNICODE);
			if ($json === false || strlen($json) > ABI_MAX_BYTES) {
				abi_out(413, ['error' => 'Daten zu groß']);
			}
			$ver = (int)($b['version'] ?? 0);
			$db->exec('BEGIN IMMEDIATE');
			$st = $db->prepare('SELECT version FROM docs WHERE user_id = ?');
			$st->execute([$uid]);
			$row = $st->fetch();
			$cur = $row ? (int)$row['version'] : 0;
			if ($ver !== $cur) {
				$db->exec('ROLLBACK');
				abi_out(409, ['error' => 'Auf dem Server liegt ein neuerer Stand', 'version' => $cur]);
			}
			if ($row) {
				$db->prepare('UPDATE docs SET json = ?, version = ?, updated_at = ? WHERE user_id = ?')->execute([$json, $cur + 1, time(), $uid]);
			} else {
				$db->prepare('INSERT INTO docs (user_id, json, version, updated_at) VALUES (?, ?, 1, ?)')->execute([$uid, $json, time()]);
			}
			$db->exec('COMMIT');
			abi_out(200, ['version' => $cur + 1]);
			break;

		case 'passwd':
			$b = abi_body();
			$keys = ['pw:' . $uid];
			if (abi_throttled($keys)) {
				abi_out(429, ['error' => 'Zu viele Versuche. Bitte später erneut versuchen.']);
			}
			$st = $db->prepare('SELECT pass FROM users WHERE id = ?');
			$st->execute([$uid]);
			if (!password_verify((string)($b['old'] ?? ''), (string)$st->fetchColumn())) {
				abi_fail($keys);
				abi_out(403, ['error' => 'Aktuelles Passwort falsch']);
			}
			$new = (string)($b['new'] ?? '');
			if (abi_len($new) < ABI_MIN_PW) {
				abi_out(400, ['error' => 'Neues Passwort: mindestens ' . ABI_MIN_PW . ' Zeichen']);
			}
			$db->prepare('UPDATE users SET pass = ? WHERE id = ?')->execute([password_hash($new, PASSWORD_DEFAULT), $uid]);
			// alle anderen Geräte abmelden
			$t = hash('sha256', (string)($_COOKIE['abi_token'] ?? ''));
			$db->prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash != ?')->execute([$uid, $t]);
			abi_out(200, ['ok' => true]);
			break;
		}
	} catch (Throwable $e) {
		error_log('[abiturplaner] ' . $e->getMessage());
		abi_out(500, ['error' => 'Server nicht eingerichtet oder Datenbank nicht erreichbar (siehe Server-Log)']);
	}
}

if (!defined('ABI_CLI')) {
	abi_handle();
}
