<?php

declare(strict_types=1);

/**
 * Abiturplaner – Server-API (PHP + SQLite)
 *
 * Benutzer, Sitzungen und Noten liegen AUSSERHALB des Webroots
 * (Standard: /var/lib/abiturplaner, änderbar über die Umgebungsvariable ABI_DATA_DIR).
 * So überschreibt der Git-Updater niemals Daten.
 *
 * Endpunkte (api.php?a=...):
 *   GET  config   -> {register: bool, invite: bool}
 *   GET  me       -> {user}            (401, wenn nicht angemeldet)
 *   GET  load     -> {data, version}
 *   POST login    {username, password}
 *   POST register {username, password, invite?}   (invite nur, wenn in config.php ein Code gesetzt ist)
 *   POST logout
 *   POST save     {data, version}      (409 bei Versionskonflikt)
 *   POST passwd   {old, new}
 *   POST delete   {password}           (löscht das eigene Konto samt Daten)
 *
 * Nur für Admin-Konten (users.is_admin, gesetzt per tools/abi.php admin NAME on) – ohne Noten/Fächer, nur Kennzahlen:
 *   GET  admin_overview               -> {stats, daily, users[]}
 *   POST admin_delete {username}      -> Konto samt Daten löschen
 *   POST admin_passwd {username}      -> neues Zufallspasswort (einmalig angezeigt), alle Sitzungen beendet
 */

const ABI_SESSION_DAYS = 30;
const ABI_MAX_BYTES = 1000000;
const ABI_MAX_FAILS = 8;     // Fehlversuche pro 15 Minuten (je IP bzw. je Benutzername)
const ABI_MIN_PW = 8;
const ABI_MAX_REG_PER_IP = 5;   // neue Konten pro Stunde und IP

// ---------------------------------------------------------------- Grundlagen
function abi_len(string $s): int {
	return function_exists('mb_strlen') ? mb_strlen($s) : strlen($s);
}

function abi_dir(): string {
	return rtrim(getenv('ABI_DATA_DIR') ?: '/var/lib/abiturplaner', '/');
}

function abi_config(): array {
	static $cfg = null;
	if ($cfg === null) {
		$cfg = ['allow_register' => true, 'invite_code' => '', 'max_users' => 200, 'trust_proxy' => false];
		$f = abi_dir() . '/config.php';
		if (is_file($f)) {
			$c = require $f;
			if (is_array($c)) {
				$cfg = array_merge($cfg, $c);
			}
		}
	}
	return $cfg;
}

function abi_db(): PDO {
	static $pdo = null;
	if ($pdo !== null) {
		return $pdo;
	}
	if (!extension_loaded('pdo_sqlite')) {
		throw new RuntimeException('PHP-Erweiterung pdo_sqlite fehlt (apt install php-sqlite3)');
	}
	$dir = abi_dir();
	if (!is_dir($dir) || !is_writable($dir)) {
		throw new RuntimeException("Datenverzeichnis fehlt oder ist nicht beschreibbar: $dir");
	}
	umask(0027);
	$pdo = new PDO('sqlite:' . $dir . '/abiturplaner.sqlite', null, null, [
		PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
		PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
	]);
	$pdo->exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
	$pdo->exec('
		CREATE TABLE IF NOT EXISTS users (
			id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, pass TEXT NOT NULL, created_at INTEGER NOT NULL);
		CREATE TABLE IF NOT EXISTS sessions (
			token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires_at INTEGER NOT NULL);
		CREATE TABLE IF NOT EXISTS docs (
			user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, json TEXT NOT NULL, version INTEGER NOT NULL, updated_at INTEGER NOT NULL);
		CREATE TABLE IF NOT EXISTS attempts (
			id INTEGER PRIMARY KEY, k TEXT NOT NULL, ts INTEGER NOT NULL);
		CREATE INDEX IF NOT EXISTS attempts_k ON attempts (k, ts);
	');
	// spätere Spalten (Admin-Bereich) bei bestehenden Datenbanken nachrüsten
	$cols = array_column($pdo->query('PRAGMA table_info(users)')->fetchAll(), 'name');
	if (!in_array('is_admin', $cols, true)) {
		$pdo->exec('ALTER TABLE users ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0');
	}
	if (!in_array('last_login', $cols, true)) {
		$pdo->exec('ALTER TABLE users ADD COLUMN last_login INTEGER');
	}
	return $pdo;
}

function abi_out(int $code, array $data): void {
	http_response_code($code);
	header('Content-Type: application/json; charset=utf-8');
	header('Cache-Control: no-store');
	header('X-Content-Type-Options: nosniff');
	echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
	exit;
}

function abi_ip(): string {
	$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
	if (abi_config()['trust_proxy'] && !empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		$ip = trim(explode(',', (string)$_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
	}
	return $ip;
}

function abi_https(): bool {
	if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
		return true;
	}
	return (bool)abi_config()['trust_proxy'] && ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https';
}

function abi_cookie_path(): string {
	return rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/') . '/';
}

function abi_set_cookie(string $value, int $expires): void {
	setcookie('abi_token', $value, [
		'expires' => $expires,
		'path' => abi_cookie_path(),
		'secure' => abi_https(),
		'httponly' => true,
		'samesite' => 'Lax',
	]);
}

// ---------------------------------------------------------------- Benutzer
function abi_norm_user(string $u): string {
	return strtolower(trim($u));
}

function abi_valid_user(string $u): bool {
	return (bool)preg_match('/^[a-z0-9._-]{3,32}$/', $u);
}

/** Legt einen Benutzer an und gibt die ID zurück (wirft Exception bei Fehlern). */
function abi_create_user(string $name, string $password): int {
	$name = abi_norm_user($name);
	if (!abi_valid_user($name)) {
		throw new InvalidArgumentException('Benutzername: 3–32 Zeichen aus a-z, 0-9, Punkt, Unterstrich, Minus');
	}
	if (abi_len($password) < ABI_MIN_PW) {
		throw new InvalidArgumentException('Passwort muss mindestens ' . ABI_MIN_PW . ' Zeichen lang sein');
	}
	$db = abi_db();
	$st = $db->prepare('SELECT 1 FROM users WHERE username = ?');
	$st->execute([$name]);
	if ($st->fetch()) {
		throw new InvalidArgumentException('Benutzername ist bereits vergeben');
	}
	try {
		$db->prepare('INSERT INTO users (username, pass, created_at) VALUES (?, ?, ?)')
			->execute([$name, password_hash($password, PASSWORD_DEFAULT), time()]);
	} catch (PDOException $e) {
		if ($e->getCode() === '23000') { // gleichzeitige Registrierung desselben Namens
			throw new InvalidArgumentException('Benutzername ist bereits vergeben');
		}
		throw $e;
	}
	return (int)$db->lastInsertId();
}

function abi_current_user(): ?array {
	$t = $_COOKIE['abi_token'] ?? '';
	if (!is_string($t) || !preg_match('/^[a-f0-9]{64}$/', $t)) {
		return null;
	}
	$st = abi_db()->prepare('SELECT u.id, u.username, u.is_admin FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > ?');
	$st->execute([hash('sha256', $t), time()]);
	return $st->fetch() ?: null;
}

function abi_start_session(int $userId): void {
	$db = abi_db();
	$db->prepare('DELETE FROM sessions WHERE expires_at < ?')->execute([time()]);
	$db->prepare('DELETE FROM attempts WHERE ts < ?')->execute([time() - 3600]);
	$token = bin2hex(random_bytes(32));
	$exp = time() + ABI_SESSION_DAYS * 86400;
	$db->prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)')
		->execute([hash('sha256', $token), $userId, $exp]);
	$db->prepare('UPDATE users SET last_login = ? WHERE id = ?')->execute([time(), $userId]);
	abi_set_cookie($token, $exp);
}

function abi_throttled(array $keys): bool {
	$db = abi_db();
	$st = $db->prepare('SELECT COUNT(*) FROM attempts WHERE k = ? AND ts > ?');
	foreach ($keys as $k) {
		$st->execute([$k, time() - 900]);
		if ((int)$st->fetchColumn() >= ABI_MAX_FAILS) {
			return true;
		}
	}
	return false;
}

/** Zählt Ereignisse eines Schlüssels im Zeitfenster (Sekunden). */
function abi_count(string $k, int $window): int {
	$st = abi_db()->prepare('SELECT COUNT(*) FROM attempts WHERE k = ? AND ts > ?');
	$st->execute([$k, time() - $window]);
	return (int)$st->fetchColumn();
}

function abi_fail(array $keys): void {
	$st = abi_db()->prepare('INSERT INTO attempts (k, ts) VALUES (?, ?)');
	foreach ($keys as $k) {
		$st->execute([$k, time()]);
	}
}

// ---------------------------------------------------------------- Anfrage
function abi_body(): array {
	$raw = (string)file_get_contents('php://input', false, null, 0, ABI_MAX_BYTES + 1024);
	if (strlen($raw) > ABI_MAX_BYTES + 512) {
		abi_out(413, ['error' => 'Daten zu groß']);
	}
	$j = json_decode($raw, true);
	return is_array($j) ? $j : [];
}

function abi_handle(): void {
	header('X-Content-Type-Options: nosniff');
	$a = (string)($_GET['a'] ?? '');
	$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
	$get = ['config', 'me', 'load', 'admin_overview'];
	$post = ['login', 'register', 'logout', 'save', 'passwd', 'delete', 'admin_delete', 'admin_passwd'];
	if (!in_array($a, array_merge($get, $post), true)) {
		abi_out(404, ['error' => 'Unbekannte Aktion']);
	}
	if (in_array($a, $post, true)) {
		if ($method !== 'POST') {
			abi_out(405, ['error' => 'POST erforderlich']);
		}
		// CSRF-Schutz: benutzerdefinierter Header löst im Browser eine CORS-Prüfung aus, die wir nie erlauben.
		if (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') !== 'abiturplaner') {
			abi_out(403, ['error' => 'Ungültige Anfrage']);
		}
	} elseif ($method !== 'GET') {
		abi_out(405, ['error' => 'GET erforderlich']);
	}

	try {
		if ($a === 'config') {
			$c = abi_config();
			abi_out(200, ['register' => (bool)$c['allow_register'], 'invite' => (bool)$c['allow_register'] && (string)$c['invite_code'] !== '']);
		}
		$db = abi_db();
		$ip = abi_ip();

		if ($a === 'login') {
			$b = abi_body();
			$name = abi_norm_user((string)($b['username'] ?? ''));
			$pw = (string)($b['password'] ?? '');
			$keys = ['ip:' . $ip, 'u:' . $name];
			if (abi_throttled($keys)) {
				abi_out(429, ['error' => 'Zu viele Fehlversuche. Bitte in 15 Minuten erneut versuchen.']);
			}
			$st = $db->prepare('SELECT id, pass, is_admin FROM users WHERE username = ?');
			$st->execute([$name]);
			$u = $st->fetch();
			// Bei unbekanntem Benutzer trotzdem hashen (gleiche Antwortzeit)
			$ok = password_verify($pw, $u ? $u['pass'] : '$2y$10$ToBrc9DJcpQZRGGAUlcBuO4PbqXDLGe.EVnrw6O0YZib48pbOSLiK');
			if (!$u || !$ok) {
				abi_fail($keys);
				abi_out(401, ['error' => 'Benutzername oder Passwort falsch']);
			}
			if (password_needs_rehash($u['pass'], PASSWORD_DEFAULT)) {
				$db->prepare('UPDATE users SET pass = ? WHERE id = ?')->execute([password_hash($pw, PASSWORD_DEFAULT), $u['id']]);
			}
			abi_start_session((int)$u['id']);
			abi_out(200, ['user' => $name, 'admin' => (bool)(int)$u['is_admin']]);
		}

		if ($a === 'register') {
			$cfg = abi_config();
			if (!$cfg['allow_register']) {
				abi_out(403, ['error' => 'Registrierung ist deaktiviert']);
			}
			$b = abi_body();
			$bad = ['ip:' . $ip];   // falsche Einladungscodes
			$made = 'regok:' . $ip; // erfolgreich angelegte Konten (Stundenlimit)
			if (abi_throttled($bad) || abi_count($made, 3600) >= ABI_MAX_REG_PER_IP) {
				abi_out(429, ['error' => 'Zu viele Versuche von dieser Adresse. Bitte später erneut versuchen.']);
			}
			if ((string)$cfg['invite_code'] !== '' && !hash_equals((string)$cfg['invite_code'], (string)($b['invite'] ?? ''))) {
				abi_fail($bad);
				abi_out(403, ['error' => 'Einladungscode falsch']);
			}
			$max = (int)$cfg['max_users'];
			if ($max > 0 && (int)$db->query('SELECT COUNT(*) FROM users')->fetchColumn() >= $max) {
				abi_out(403, ['error' => 'Es können keine neuen Konten mehr angelegt werden (Limit erreicht).']);
			}
			$name = abi_norm_user((string)($b['username'] ?? ''));
			try {
				$id = abi_create_user($name, (string)($b['password'] ?? ''));
			} catch (InvalidArgumentException $e) {
				abi_out(400, ['error' => $e->getMessage()]);
			}
			abi_fail([$made]);
			abi_start_session($id);
			abi_out(200, ['user' => $name]);
		}

		$user = abi_current_user();
		if (!$user) {
			abi_out(401, ['error' => 'Nicht angemeldet']);
		}
		$uid = (int)$user['id'];
		if (strncmp($a, 'admin_', 6) === 0 && !(int)$user['is_admin']) {
			abi_out(403, ['error' => 'Keine Admin-Berechtigung']);
		}

		switch ($a) {
		case 'me':
			abi_out(200, ['user' => $user['username'], 'admin' => (bool)(int)$user['is_admin']]);
			break;

		case 'logout':
			$t = (string)($_COOKIE['abi_token'] ?? '');
			$db->prepare('DELETE FROM sessions WHERE token_hash = ?')->execute([hash('sha256', $t)]);
			abi_set_cookie('', time() - 3600);
			abi_out(200, ['ok' => true]);
			break;

		case 'load':
			$st = $db->prepare('SELECT json, version FROM docs WHERE user_id = ?');
			$st->execute([$uid]);
			$row = $st->fetch();
			abi_out(200, $row ? ['data' => json_decode($row['json'], true), 'version' => (int)$row['version']] : ['data' => null, 'version' => 0]);
			break;

		case 'save':
			$b = abi_body();
			$data = $b['data'] ?? null;
			if (!is_array($data) || !isset($data['fachs']) || !is_array($data['fachs']) || count($data['fachs']) > 60) {
				abi_out(400, ['error' => 'Ungültige Daten']);
			}
			$json = json_encode($data, JSON_UNESCAPED_UNICODE);
			if ($json === false || strlen($json) > ABI_MAX_BYTES) {
				abi_out(413, ['error' => 'Daten zu groß']);
			}
			$ver = (int)($b['version'] ?? 0);
			$db->exec('BEGIN IMMEDIATE');
			$st = $db->prepare('SELECT version FROM docs WHERE user_id = ?');
			$st->execute([$uid]);
			$row = $st->fetch();
			$cur = $row ? (int)$row['version'] : 0;
			if ($ver !== $cur) {
				$db->exec('ROLLBACK');
				abi_out(409, ['error' => 'Auf dem Server liegt ein neuerer Stand', 'version' => $cur]);
			}
			if ($row) {
				$db->prepare('UPDATE docs SET json = ?, version = ?, updated_at = ? WHERE user_id = ?')->execute([$json, $cur + 1, time(), $uid]);
			} else {
				$db->prepare('INSERT INTO docs (user_id, json, version, updated_at) VALUES (?, ?, 1, ?)')->execute([$uid, $json, time()]);
			}
			$db->exec('COMMIT');
			abi_out(200, ['version' => $cur + 1]);
			break;

		case 'passwd':
			$b = abi_body();
			$keys = ['pw:' . $uid];
			if (abi_throttled($keys)) {
				abi_out(429, ['error' => 'Zu viele Versuche. Bitte später erneut versuchen.']);
			}
			$st = $db->prepare('SELECT pass FROM users WHERE id = ?');
			$st->execute([$uid]);
			if (!password_verify((string)($b['old'] ?? ''), (string)$st->fetchColumn())) {
				abi_fail($keys);
				abi_out(403, ['error' => 'Aktuelles Passwort falsch']);
			}
			$new = (string)($b['new'] ?? '');
			if (abi_len($new) < ABI_MIN_PW) {
				abi_out(400, ['error' => 'Neues Passwort: mindestens ' . ABI_MIN_PW . ' Zeichen']);
			}
			$db->prepare('UPDATE users SET pass = ? WHERE id = ?')->execute([password_hash($new, PASSWORD_DEFAULT), $uid]);
			// alle anderen Geräte abmelden
			$t = hash('sha256', (string)($_COOKIE['abi_token'] ?? ''));
			$db->prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash != ?')->execute([$uid, $t]);
			abi_out(200, ['ok' => true]);
			break;

		case 'delete':
			$b = abi_body();
			$keys = ['pw:' . $uid];
			if (abi_throttled($keys)) {
				abi_out(429, ['error' => 'Zu viele Versuche. Bitte später erneut versuchen.']);
			}
			$st = $db->prepare('SELECT pass FROM users WHERE id = ?');
			$st->execute([$uid]);
			if (!password_verify((string)($b['password'] ?? ''), (string)$st->fetchColumn())) {
				abi_fail($keys);
				abi_out(403, ['error' => 'Passwort falsch']);
			}
			$db->prepare('DELETE FROM users WHERE id = ?')->execute([$uid]); // Sitzungen und Daten folgen per CASCADE
			abi_set_cookie('', time() - 3600);
			abi_out(200, ['ok' => true]);
			break;

		case 'admin_overview':
			date_default_timezone_set('Europe/Berlin');
			$rows = $db->query('SELECT u.id, u.username, u.created_at, u.last_login, u.is_admin, d.version, d.updated_at
				FROM users u LEFT JOIN docs d ON d.user_id = u.id ORDER BY u.created_at DESC')->fetchAll();
			$now = time();
			$list = [];
			$stats = ['users' => count($rows), 'admins' => 0, 'with_data' => 0, 'new_7d' => 0, 'new_30d' => 0, 'active_7d' => 0, 'active_30d' => 0];
			$daily = [];
			for ($i = 29; $i >= 0; $i--) {
				$daily[date('Y-m-d', $now - $i * 86400)] = 0;
			}
			foreach ($rows as $r) {
				$created = (int)$r['created_at'];
				$login = $r['last_login'] === null ? null : (int)$r['last_login'];
				$saved = $r['updated_at'] === null ? null : (int)$r['updated_at'];
				$act = max((int)$login, (int)$saved, 0) ?: null; // letzte Aktivität
				$stats['admins'] += (int)$r['is_admin'];
				$stats['with_data'] += $saved !== null ? 1 : 0;
				$stats['new_7d'] += $created > $now - 7 * 86400 ? 1 : 0;
				$stats['new_30d'] += $created > $now - 30 * 86400 ? 1 : 0;
				$stats['active_7d'] += $act !== null && $act > $now - 7 * 86400 ? 1 : 0;
				$stats['active_30d'] += $act !== null && $act > $now - 30 * 86400 ? 1 : 0;
				$day = date('Y-m-d', $created);
				if (isset($daily[$day])) {
					$daily[$day]++;
				}
				// bewusst KEINE Fächer/Noten – nur Kontodaten und Zeitstempel
				$list[] = ['username' => $r['username'], 'created_at' => $created, 'last_login' => $login, 'last_save' => $saved,
					'saves' => (int)($r['version'] ?? 0), 'admin' => (bool)(int)$r['is_admin'], 'self' => (int)$r['id'] === $uid];
			}
			$cfg = abi_config();
			$stats['register_open'] = (bool)$cfg['allow_register'];
			$stats['invite'] = (string)$cfg['invite_code'] !== '';
			$stats['max_users'] = (int)$cfg['max_users'];
			$f = abi_dir() . '/abiturplaner.sqlite';
			$stats['db_bytes'] = is_file($f) ? (int)filesize($f) : 0;
			$out = [];
			foreach ($daily as $d => $n) {
				$out[] = ['d' => $d, 'n' => $n];
			}
			abi_out(200, ['stats' => $stats, 'daily' => $out, 'users' => $list]);
			break;

		case 'admin_delete':
		case 'admin_passwd':
			$b = abi_body();
			$name = abi_norm_user((string)($b['username'] ?? ''));
			$st = $db->prepare('SELECT id, is_admin FROM users WHERE username = ?');
			$st->execute([$name]);
			$t = $st->fetch();
			if (!$t) {
				abi_out(404, ['error' => 'Benutzer nicht gefunden']);
			}
			if ((int)$t['id'] === $uid || (int)$t['is_admin']) {
				abi_out(400, ['error' => 'Admin-Konten (auch das eigene) werden hier nicht verwaltet – per Kommandozeile (tools/abi.php).']);
			}
			if ($a === 'admin_delete') {
				$db->prepare('DELETE FROM users WHERE id = ?')->execute([$t['id']]); // Sitzungen und Daten folgen per CASCADE
				abi_out(200, ['ok' => true]);
			}
			$alphabet = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
			$pw = '';
			for ($i = 0; $i < 12; $i++) {
				$pw .= $alphabet[random_int(0, strlen($alphabet) - 1)];
			}
			$db->prepare('UPDATE users SET pass = ? WHERE id = ?')->execute([password_hash($pw, PASSWORD_DEFAULT), $t['id']]);
			$db->prepare('DELETE FROM sessions WHERE user_id = ?')->execute([$t['id']]);
			abi_out(200, ['password' => $pw]);
			break;
		}
	} catch (Throwable $e) {
		error_log('[abiturplaner] ' . $e->getMessage());
		abi_out(500, ['error' => 'Server nicht eingerichtet oder Datenbank nicht erreichbar (siehe Server-Log)']);
	}
}

if (!defined('ABI_CLI')) {
	abi_handle();
}
