// Netzwerk zuerst (damit Updates vom Git-Updater sofort ankommen), Cache nur als Offline-Fallback.
const CACHE = 'abiturplaner-v6';
const ASSETS = ['./', './index.html', './css/style.css', './js/calc.js', './js/main.js', './manifest.webmanifest', './img/icon.svg'];

self.addEventListener('install', (e) => {
	e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
	e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
	const req = e.request;
	const u = new URL(req.url);
	if (req.method !== 'GET' || u.origin !== location.origin || u.pathname.endsWith('/api.php')) return; // API nie cachen
	e.respondWith(
		fetch(req).then((res) => {
			if (res.ok) {
				const copy = res.clone();
				caches.open(CACHE).then((c) => c.put(req, copy));
			}
			return res;
		}).catch(() => caches.match(req).then((m) => m || caches.match('./index.html')))
	);
});
