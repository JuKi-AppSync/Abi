/* Abiturplaner – Admin-Bereich: Kennzahlen und Kontenverwaltung. Zeigt bewusst keine Fächer oder Noten. */
(function () {
	'use strict'
	const root = document.getElementById('admin')
	const API = '../api.php'
	const $ = (s) => root.querySelector(s)
	const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]))
	let data = null
	let filter = ''
	let notice = ''

	async function api(action, body) {
		const opt = { credentials: 'same-origin', headers: { 'X-Requested-With': 'abiturplaner' } }
		if (body !== undefined) {
			opt.method = 'POST'
			opt.headers['Content-Type'] = 'application/json'
			opt.body = JSON.stringify(body)
		}
		const r = await fetch(`${API}?a=${action}`, opt)
		let j = {}
		try { j = await r.json() } catch (e) { /* keine JSON-Antwort */ }
		return { ok: r.ok, status: r.status, j }
	}

	const dt = (t) => (t ? new Date(t * 1000).toLocaleString('de-DE', { dateStyle: 'medium', timeStyle: 'short' }) : '–')
	const day = (t) => (t ? new Date(t * 1000).toLocaleDateString('de-DE', { dateStyle: 'medium' }) : '–')
	function ago(t) {
		if (!t) return 'nie'
		const d = Math.floor((Date.now() / 1000 - t) / 86400)
		return d <= 0 ? 'heute' : d === 1 ? 'gestern' : `vor ${d} Tagen`
	}
	const size = (b) => (b > 1048576 ? (b / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(b / 1024)) + ' KB')

	function login(msg) {
		root.innerHTML = `<div class="abi-login"><h2>Admin</h2>
			<p class="abi-hint">Melde dich mit einem Admin-Konto an.</p>
			<form class="abi-lf" id="lf">
				<label>Benutzername<input name="username" autocomplete="username" autocapitalize="none" spellcheck="false" required></label>
				<label>Passwort<input name="password" type="password" autocomplete="current-password" required></label>
				<p class="abi-fail" id="lerr">${esc(msg || '')}</p>
				<button class="primary" type="submit">Anmelden</button>
			</form></div>`
		$('#lf').addEventListener('submit', async (e) => {
			e.preventDefault()
			const btn = e.target.querySelector('button')
			btn.disabled = true
			try {
				const r = await api('login', Object.fromEntries(new FormData(e.target).entries()))
				if (!r.ok) {
					$('#lerr').textContent = r.j.error || 'Fehler (' + r.status + ')'
					btn.disabled = false
					return
				}
				await load()
			} catch (err) {
				$('#lerr').textContent = 'Server nicht erreichbar'
				btn.disabled = false
			}
		})
	}

	async function load() {
		const r = await api('admin_overview')
		if (r.status === 401) return login()
		if (r.status === 403) {
			root.innerHTML = `<div class="abi-login"><h2>Kein Zugriff</h2><p class="abi-fail">Dieses Konto ist kein Admin.</p>
				<p class="abi-hint">Admin vergeben (auf dem Server): <code>sudo -u www-data php tools/abi.php admin BENUTZERNAME</code></p>
				<button data-act="logout">Abmelden</button> <a href="../">Zur App</a></div>`
			return
		}
		if (!r.ok) {
			root.innerHTML = `<div class="abi-login"><p class="abi-fail">${esc(r.j.error || 'Fehler ' + r.status)}</p><button data-act="reload">Erneut versuchen</button></div>`
			return
		}
		data = r.j
		render()
	}

	function bars(daily) {
		const W = Math.min(960, Math.max(300, root.clientWidth - 40 || 640)), H = 170, ml = 28, mr = 8, mt = 12, mb = 26
		const max = Math.max(3, ...daily.map((x) => x.n))
		const step = max > 12 ? 5 : max > 6 ? 2 : 1
		const top = Math.ceil(max / step) * step
		const pw = W - ml - mr, ph = H - mt - mb, bw = pw / daily.length
		const Y = (v) => mt + ph * (1 - v / top)
		let g = ''
		for (let v = 0; v <= top; v += step) g += `<line x1="${ml}" x2="${W - mr}" y1="${Y(v).toFixed(1)}" y2="${Y(v).toFixed(1)}" class="ch-grid"/><text x="${ml - 5}" y="${(Y(v) + 4).toFixed(1)}" text-anchor="end">${v}</text>`
		daily.forEach((x, i) => {
			const h = Math.max(0, Y(0) - Y(x.n))
			const dd = new Date(x.d + 'T12:00:00').toLocaleDateString('de-DE', { day: 'numeric', month: 'numeric' })
			g += `<rect x="${(ml + i * bw + 1.5).toFixed(1)}" y="${Y(x.n).toFixed(1)}" width="${Math.max(2, bw - 3).toFixed(1)}" height="${h.toFixed(1)}" rx="2" class="ch-bar s"><title>${esc(dd)}: ${x.n} neue(s) Konto/Konten</title></rect>`
			if (i % 5 === 0 || i === daily.length - 1) g += `<text x="${(ml + i * bw + bw / 2).toFixed(1)}" y="${H - 8}" text-anchor="middle">${esc(dd)}</text>`
		})
		return `<svg class="ch" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" aria-label="Neue Konten pro Tag, letzte 30 Tage">${g}</svg>`
	}

	function card(label, big, sub) {
		return `<div class="abi-card"><div class="abi-lbl">${label}</div><div class="abi-big">${big}</div><div class="abi-sub">${sub}</div></div>`
	}

	function rows() {
		const q = filter.trim().toLowerCase()
		const list = data.users.filter((u) => !q || u.username.includes(q))
		if (!list.length) return '<tr><td colspan="6">Keine Konten gefunden.</td></tr>'
		return list.map((u) => {
			const act = Math.max(u.last_login || 0, u.last_save || 0) || null
			const acts = u.admin
				? '<small>Admin – nur per Kommandozeile</small>'
				: `<button data-act="pw" data-u="${esc(u.username)}">Passwort zurücksetzen</button> <button class="danger" data-act="del" data-u="${esc(u.username)}">Löschen</button>`
			return `<tr><td>${esc(u.username)}${u.admin ? ' <span class="abi-badge">Admin</span>' : ''}${u.self ? ' <span class="abi-badge gfs">du</span>' : ''}</td>
				<td title="${esc(dt(u.created_at))}">${day(u.created_at)}</td>
				<td title="${esc(dt(act))}">${ago(act)}</td>
				<td>${u.saves ? `${u.saves}× · ${ago(u.last_save)}` : '<small>noch nie</small>'}</td>
				<td>${acts}</td></tr>`
		}).join('')
	}

	function render() {
		const s = data.stats
		const cap = s.max_users ? ` / ${s.max_users}` : ''
		root.innerHTML = `
			<div class="abi-top"><h2>Abiturplaner – Admin</h2>
				<span class="abi-user"><a href="../">Zur App</a> <button data-act="reload">Aktualisieren</button> <button data-act="logout">Abmelden</button></span></div>
			${notice ? `<p class="abi-hint" id="notice"><b>${notice}</b></p>` : ''}
			<div class="abi-grid">
				${card('Konten', s.users + cap, `davon ${s.admins} Admin${s.admins === 1 ? '' : 's'}`)}
				${card('Neu', s.new_7d, `in 7 Tagen · ${s.new_30d} in 30 Tagen`)}
				${card('Aktiv', s.active_7d, `in 7 Tagen · ${s.active_30d} in 30 Tagen`)}
				${card('Mit Daten', s.with_data, `${s.users - s.with_data} Konto/Konten haben noch nie gespeichert`)}
			</div>
			<section><h3>Neue Konten pro Tag (letzte 30 Tage)</h3><div class="ch-wrap">${bars(data.daily)}</div></section>
			<section><h3>System</h3>
				<p class="abi-hint">Registrierung: <b>${s.register_open ? 'offen' : 'geschlossen'}</b>${s.invite ? ' (mit Einladungscode)' : ''} · Datenbank: ${size(s.db_bytes)}
				· Ändern auf dem Server: <code>php tools/abi.php register on|off</code></p></section>
			<section><h3>Konten</h3>
				<p class="abi-hint">Fächer und Noten sind hier bewusst nicht sichtbar – nur Kontodaten und Zeitpunkte. „Aktiv“ = letzte Anmeldung oder letztes Speichern.</p>
				<div class="abi-bar"><label>Suchen <input id="q" type="search" value="${esc(filter)}" placeholder="Benutzername" autocomplete="off"></label></div>
				<div class="abi-scroll"><table class="abi-t"><thead><tr><th>Benutzer</th><th>Angelegt</th><th>Zuletzt aktiv</th><th>Speicherungen</th><th></th></tr></thead><tbody id="rows">${rows()}</tbody></table></div>
			</section>`
		$('#q').addEventListener('input', (e) => {
			filter = e.target.value
			$('#rows').innerHTML = rows()
		})
	}

	root.addEventListener('click', async (e) => {
		const t = e.target.closest('[data-act]')
		if (!t) return
		const u = t.dataset.u
		switch (t.dataset.act) {
		case 'reload':
			notice = ''
			load()
			break
		case 'logout':
			await api('logout', {})
			login()
			break
		case 'del': {
			const typed = prompt(`Konto "${u}" mit ALLEN Daten unwiderruflich löschen?\n\nZur Bestätigung den Benutzernamen eintippen:`)
			if (typed === null) return
			if (typed.trim().toLowerCase() !== u) {
				alert('Benutzername stimmt nicht überein – nichts gelöscht.')
				return
			}
			const r = await api('admin_delete', { username: u })
			notice = r.ok ? `Konto „${esc(u)}“ wurde gelöscht.` : esc(r.j.error || 'Fehler')
			await load()
			break
		}
		case 'pw': {
			if (!confirm(`Für "${u}" ein neues Zufallspasswort setzen? Alle Sitzungen dieses Kontos werden beendet.`)) return
			const r = await api('admin_passwd', { username: u })
			notice = r.ok
				? `Neues Passwort für „${esc(u)}“: <code style="user-select:all">${esc(r.j.password)}</code> – wird nur jetzt angezeigt. Bitte sicher weitergeben; der Nutzer kann es unter „Einrichtung“ ändern.`
				: esc(r.j.error || 'Fehler')
			await load()
			break
		}
		}
	})

	load().catch(() => {
		root.innerHTML = '<div class="abi-login"><p class="abi-fail">Der Server ist nicht erreichbar.</p><button data-act="reload">Erneut versuchen</button></div>'
	})
})()
