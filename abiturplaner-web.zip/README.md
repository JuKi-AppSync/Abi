# Abiturplaner BW – Web-Version mit Login und Server-Speicherung

Statische Seite (HTML/JS/CSS) + kleines PHP-Backend (`api.php`, SQLite).

## Schnellinstallation (Apache, Raspberry Pi)

1. Lade `abiturplaner-web.zip` **und** `install.sh` ins GitHub-Repo hoch (Hauptverzeichnis, Repo öffentlich).
2. Auf dem Pi (einmalig):
   ```bash
   wget -O /tmp/install.sh https://github.com/JuKi-AppSync/Abi/raw/main/install.sh
   sudo bash /tmp/install.sh
   ```
   Das Skript fragt nach Domain (Vorgabe `kimpfler.selfhost.eu`), Adresspfad (`/abi`), Zielordner und optional einem ersten Konto (leer lassen = im Browser registrieren).
3. Öffnen: `https://kimpfler.selfhost.eu/abi/`

**Was das Skript an Apache ändert:** Es findet mit `apache2ctl -S` den VirtualHost der gewählten Domain (HTTPS bevorzugt) und fügt dort
drei Zeilen ein (`IncludeOptional /etc/abiturplaner/apache.conf`, markiert mit `# BEGIN/END abiturplaner`). Vorher wird eine Sicherung
nach `/etc/abiturplaner/backup/` gelegt; besteht Apache den Konfigurationstest nicht, wird die Änderung sofort zurückgenommen.
Andere Domains, Nextclouds und Subdomains bleiben unberührt, deine bestehende Seite auf der Domain läuft weiter.
Bei PHP-FPM wird der PHP-Handler nur für den App-Ordner gesetzt.
Hinweis: Erneuert Certbot die VirtualHost-Datei komplett neu (`certbot install`), den Eintrag mit `sudo bash /tmp/install.sh` erneut setzen (idempotent).

**Neue Version einspielen:** ZIP im Repo ersetzen (gleicher Dateiname). Der Pi holt sie nachts um 03:30 oder sofort mit `sudo abiturplaner-install update`.
Noten und Konten liegen in `/var/lib/abiturplaner` und bleiben bei Updates unberührt. Täglich 03:00 wird eine Sicherung angelegt.

Weitere Befehle: `sudo bash /tmp/install.sh uninstall` (entfernt App und Apache-Eintrag, Daten bleiben) bzw. `... uninstall --purge` (alles löschen).
Andere Domain/ZIP: `sudo ABI_DOMAIN=andere.domain.de ABI_ZIP=https://... bash /tmp/install.sh`.
Manuell einbinden (falls das Skript den VirtualHost nicht findet): in den `<VirtualHost *:443>` der Domain die Zeile `IncludeOptional /etc/abiturplaner/apache.conf` setzen.

---

## Manuelle Einrichtung (statt Schnellinstallation)
Benutzer, Sitzungen und Noten liegen **außerhalb des Webroots** (Standard `/var/lib/abiturplaner`),
deshalb überschreibt dein täglicher Git-Updater niemals Daten.

## Voraussetzungen
- Webserver mit PHP (>= 8.0) für diese Domain (Apache mit PHP oder nginx mit PHP-FPM)
- PHP-Erweiterung `pdo_sqlite`:  `php -m | grep -i sqlite`  (sonst: `sudo apt install php-sqlite3`, danach PHP-FPM/Apache neu starten)
- HTTPS (Passwörter!) – ohne HTTPS nur im Heimnetz verwenden

## Einrichtung (einmalig, auf dem Pi)
```bash
# 1. Datenordner außerhalb des Webroots
sudo mkdir -p /var/lib/abiturplaner
sudo chown www-data:www-data /var/lib/abiturplaner
sudo chmod 750 /var/lib/abiturplaner

# 2. Datenbank und Konfiguration anlegen (im Ordner der Webseite, www-data = Benutzer des Webservers)
cd /PFAD/ZUR/WEBSEITE
sudo -u www-data php tools/abi.php init

# 3. Ersten Benutzer anlegen (Passwort wird abgefragt, mind. 8 Zeichen)
sudo -u www-data php tools/abi.php adduser DEIN_NAME   # optional – Registrierung im Browser geht auch
```
Test im Browser: `https://DEINE-DOMAIN/api.php?a=config` muss `{"register":true,"invite":false}` anzeigen.
Danach `https://DEINE-DOMAIN/` öffnen und anmelden.

## Weitere Benutzer
```bash
sudo -u www-data php tools/abi.php adduser freund1        # anlegen
sudo -u www-data php tools/abi.php passwd freund1         # Passwort zurücksetzen
sudo -u www-data php tools/abi.php deluser freund1        # Konto samt Daten löschen
sudo -u www-data php tools/abi.php list                   # alle Konten
```
## Registrierung und Konten
Auf der Anmeldeseite gibt es den Reiter **Registrieren** (Benutzername, Passwort mind. 8 Zeichen, Wiederholung). Neue Konten starten mit **komplett leerer Kurswahl**.
Nutzer können ihr Passwort ändern und ihr Konto selbst löschen (Einrichtung).
```bash
sudo -u www-data php tools/abi.php register off     # Registrierung abschalten (on = wieder an)
```
Weitere Einstellungen in `/var/lib/abiturplaner/config.php`: `'invite_code' => 'GEHEIM'` (Code wird dann bei der Registrierung verlangt),
`'max_users' => 200` (Konto-Limit, 0 = unbegrenzt). Pro IP sind höchstens 5 neue Konten pro Stunde möglich. Änderungen greifen nach wenigen Sekunden (OPcache).
**Bestehende Installation:** dort steht die Registrierung noch auf `false` – einmalig `register on` ausführen. Ein Update schaltet sie nicht von selbst ein.

## Admin-Bereich
Erreichbar unter `https://DOMAIN/abi/admin/` (Link „Admin“ erscheint in der App auch im Kopf). Anmeldung mit einem Admin-Konto, das du auf dem Server festlegst:
```bash
sudo -u www-data php tools/abi.php admin DEIN_NAME        # Admin vergeben (… off = entziehen)
```
Das beim Installieren angelegte erste Konto ist automatisch Admin. Angezeigt werden nur Kennzahlen: Anzahl Konten, Neuanmeldungen (7/30 Tage und Diagramm der letzten 30 Tage),
aktive Konten, Datenbankgröße sowie je Konto Name, Anlegedatum, letzte Aktivität und Zahl der Speicherungen – **keine Fächer und keine Noten**.
Verwalten: Konto löschen (Bestätigung durch Eintippen des Namens) und Passwort zurücksetzen (Zufallspasswort, wird einmalig angezeigt, alle Sitzungen des Kontos enden).
Admin-Konten selbst lassen sich nur per Kommandozeile ändern oder löschen. Der Server-Betreiber kann Daten technisch weiterhin in der Datenbank einsehen.
Bestehende Datenbanken werden beim Update automatisch um die nötigen Spalten ergänzt.

## Regelgrundlage und Prüfung gegen die Vorschriften
Die Rechenlogik wurde gegen den **Leitfaden für die gymnasiale Oberstufe, Abitur 2028** (Kultusministerium Baden-Württemberg, Stand 12/2025) geprüft:
https://km.baden-wuerttemberg.de/fileadmin/redaktion/m-km/intern/PDF/Publikationen/Gymnasium/2025-12-16-Leitfaden-ABI-2028.pdf

**Bestätigt (stimmte schon):** 40 Kurse in Block I, zwei Leistungsfächer doppelt (max. 600), mind. 200 Punkte, höchstens 8 Kurse unter 5 Punkten (davon höchstens 3 in Leistungsfächern), kein Kurs mit 0 Punkten;
Block II: 5 Prüfungen, mind. 100 Punkte, 3 Fächer mit je mind. 20 (4-fach) Punkten, davon 2 Leistungsfächer, schriftlich:mündlich 2:1, fachpraktisch gleich gewichtet; komplette Punkte-Noten-Tabelle (300–900); GFS zählt wie eine Klausur.

**Korrigiert:**
- Prüfungsergebnis: PF = (2s+m)/3 bleibt ungerundet, **erst nach ×4 wird gerundet** (Ziff. 1.5.5). Vorher wurde vor dem ×4 gerundet (bis ±2 Punkte Abweichung je Fach).
- Kommunikationsprüfung (moderne Fremdsprache): schriftlicher Teil **3-fach**, Kommunikation 1-fach (Ziff. 1.4.2), vorher 2:1.
- Anrechnungspflicht (Ziff. 1.5.2): Pflicht sind nur Deutsch/Mathematik/Geschichte (je 4), Geographie/Gemeinschaftskunde (belegpflichtige), Bildende Kunst oder Musik (2) sowie **je 4 Kurse in einer Fremdsprache und einer Naturwissenschaft**. Ethik, Religion, Sport, Informatik sind nur als Prüfungsfach pflichtig, sonst frei wählbar (vorher fälschlich je 4 Pflichtkurse). Bei mehreren Fremdsprachen/Naturwissenschaften wird automatisch eines als Pflicht gewertet.
- Neue Prüfungen in der Einrichtung: GFS nur in den ersten drei Halbjahren, 4 Kurse Fremdsprache/Naturwissenschaft, BK/Musik mit 2 Kursen.
- Bereits gespeicherte Fächer behalten ihren eingestellten Wert „Mindestanzahl anzurechnender Kurse“; nur neu angelegte Fächer bekommen die korrigierten Vorgaben.

**Nicht geregelt / Annahmen (bitte bei der Schule erfragen):**
- Verhältnis Klausur : mündliche (bzw. praktische) Note in der Kursnote – steht nicht im Leitfaden, die Fachlehrkraft entscheidet. Standard hier 50:50, pro Fach einstellbar.
- Sport/BK/Musik als **mündliches** Prüfungsfach mit fachpraktischem Anteil: Gewichtung für das Gymnasium nicht genannt, die App rechnet mündlich 1 : fachpraktisch 2.
- Nicht abgebildet: Besondere Lernleistung/Seminarkurs sowie die Zusatzprüfungs-Regeln bei 0 Punkten.

## Drucken / PDF
Oben rechts „Drucken / PDF“ (oder Strg+P): Es erscheint ein eigener A4-Bogen mit Ergebnis, Kurstabelle (angerechnet/nicht angerechnet), Prüfungen und Regelprüfung. Im Druckdialog „Als PDF speichern“ wählen.

## Sport und fehlende Prüfungen
Sport hat Klausuren und **praktische** Noten (statt mündlicher; Einrichtung → Fach → „Praktische statt mündliche Noten“, Standard 50/50). Ältere Daten werden automatisch erkannt.
Prüfungsfächer ohne jede Datenlage (weder Prüfung noch Kursnoten) werden in Block II mit dem Schnitt der übrigen exakten bzw. vorhergesagten Prüfungen angesetzt.

## Beispieldaten zum Testen
`beispiel/beispiel-komplett.json` (alle 4 Halbjahre + Prüfungen, 712 Punkte, Abiturnote 1,7) und `beispiel/beispiel-bis-13-1.json` (Hochrechnung bis 13/1).
Import: Einrichtung → Daten → „Aus JSON wiederherstellen“.

## Sicherung
```bash
sudo -u www-data php tools/abi.php backup            # -> /var/lib/abiturplaner/backups (letzte 14 bleiben)
```
Täglich automatisch (`/etc/cron.d/abiturplaner`):
```
0 3 * * * www-data php /PFAD/ZUR/WEBSEITE/tools/abi.php backup
```
Kopiere die Sicherungen zusätzlich auf ein anderes Gerät.

## Webserver-Hinweise
- **nginx:** `tools/` sperren (Apache nutzt die mitgelieferte `.htaccess`; das Skript bricht über das Web ohnehin ab):
  ```
  location ^~ /tools/ { deny all; }
  ```
- **Hinter einem Reverse-Proxy:** in `config.php` `'trust_proxy' => true` setzen (nur dann!), sonst zählt die Fehlversuch-Sperre die Proxy-IP.
- Falls PHP `open_basedir` nutzt: `/var/lib/abiturplaner` freigeben.

## Sicherheit (Kurzfassung)
Passwörter als bcrypt/argon2-Hash, zufällige Sitzungs-Token (nur Hash gespeichert, HttpOnly-Cookie, SameSite=Lax, Secure bei HTTPS),
CSRF-Schutz per Pflicht-Header, Sperre nach 8 Fehlversuchen / 15 Minuten, Größenlimit 1 MB.
Der Server-Admin kann Noten technisch einsehen. Kein E-Mail-Reset: Passwörter setzt der Admin per `passwd` zurück.

## Update
Dateien ersetzen bzw. per Git-Updater holen – Daten bleiben erhalten (liegen in `/var/lib/abiturplaner`).
Bei Änderungen an der Datenstruktur migriert die App alte Daten automatisch.
