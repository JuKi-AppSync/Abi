/* Abiturplaner BW – Oberfläche (reines JavaScript, kein Build-Schritt nötig) */
(function () {
	'use strict'
	const C = window.AbiCalc
	const root = document.getElementById('abiturplaner')
	if (!root) return
	if (!C) {
		root.textContent = 'Fehler: calc.js konnte nicht geladen werden.'
		return
	}

	let state = null
	let view = 'home'
	let modal = null // { f: fachId, h: halbjahr }
	let timer = null

	// ---------- Helfer ----------
	const $ = (s) => root.querySelector(s)
	const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]))
	const pts = (v) => {
		if (v === '' || v == null) return null
		const n = Math.round(Number(v))
		return Number.isFinite(n) ? Math.max(0, Math.min(15, n)) : null
	}
	const int = (v, a, b) => {
		const n = Math.round(Number(v))
		return Number.isFinite(n) ? Math.max(a, Math.min(b, n)) : a
	}
	const cls = (p) => (p == null ? 'none' : p >= 10 ? 'good' : p >= 5 ? 'mid' : 'bad')
	const ICON = { ok: '✓', warn: '!', fail: '✕', info: 'i' }
	const checks = (list) => `<ul class="abi-checks">${list.map((c) => `<li class="abi-${c.s}"><span>${ICON[c.s]}</span>${esc(c.t)}</li>`).join('')}</ul>`

	function kurs(fid, h) {
		const a = (state.kurse[fid] = state.kurse[fid] || [{}, {}, {}, {}])
		while (a.length < 4) a.push({})
		a[h] = a[h] || {}
		a[h].arb = a[h].arb || []
		a[h].mu = a[h].mu || []
		return a[h]
	}
	const fach = (id) => state.fachs.find((f) => f.id === id)

	// ---------- Server-Kommunikation ----------
	const API = 'api.php'
	const PENDING = 'abiturplaner.pending'
	let user = null
	let version = 0
	let regOpen = false
	let mode = 'login'
	let saving = false
	let dirty = false
	let retry = null

	async function api(action, body, keepalive) {
		const opt = { credentials: 'same-origin', headers: { 'X-Requested-With': 'abiturplaner' }, keepalive: !!keepalive }
		if (body !== undefined) {
			opt.method = 'POST'
			opt.headers['Content-Type'] = 'application/json'
			opt.body = JSON.stringify(body)
		}
		const r = await fetch(`${API}?a=${action}`, opt)
		let j = {}
		try {
			j = await r.json()
		} catch (e) { /* keine JSON-Antwort */ }
		return { ok: r.ok, status: r.status, j }
	}

	function status(t) {
		const el = $('#sv')
		if (el) el.textContent = t
	}
	function stash() {
		try {
			localStorage.setItem(PENDING, JSON.stringify({ user, state }))
		} catch (e) { /* ignorieren */ }
	}
	function changed() {
		status('Änderungen …')
		clearTimeout(timer)
		timer = setTimeout(() => save(), 700)
	}

	async function save(keepalive) {
		clearTimeout(timer)
		clearTimeout(retry)
		timer = null
		if (!user || !state) return
		if (saving) {
			dirty = true
			return
		}
		saving = true
		try {
			status('Speichert …')
			const r = await api('save', { data: state, version }, keepalive)
			if (r.ok) {
				version = r.j.version
				status('Auf dem Server gespeichert ✓')
				localStorage.removeItem(PENDING)
			} else if (r.status === 401) {
				stash()
				user = null
				showLogin('Sitzung abgelaufen – bitte erneut anmelden. Deine letzten Änderungen werden danach wiederhergestellt.')
			} else if (r.status === 409) {
				await conflict(r.j.version)
			} else {
				stash()
				status('Fehler beim Speichern: ' + (r.j.error || r.status))
				retry = setTimeout(() => save(), 20000)
			}
		} catch (e) {
			stash()
			status('Offline – wird automatisch erneut versucht')
			retry = setTimeout(() => save(), 15000)
		}
		saving = false
		if (dirty) {
			dirty = false
			save()
		}
	}

	async function conflict(serverVersion) {
		const useServer = confirm('Auf dem Server liegt ein neuerer Stand (z. B. von einem anderen Gerät).\n\nOK = Server-Stand laden (deine letzten Änderungen hier gehen verloren)\nAbbrechen = meinen Stand behalten und den Server überschreiben')
		if (useServer) {
			await loadData(true)
			render()
		} else {
			version = serverVersion
			dirty = true
		}
	}

	async function loadData(skipRecovery) {
		const r = await api('load')
		if (r.status === 401) throw new Error('Nicht angemeldet')
		if (!r.ok) throw new Error(r.j.error || 'HTTP ' + r.status)
		version = r.j.version || 0
		state = r.j.data ? C.migrate(r.j.data) : C.defaultState()
		if (skipRecovery) return
		let restore = false
		try {
			const p = JSON.parse(localStorage.getItem(PENDING) || 'null')
			if (p && p.user === user) {
				restore = confirm('Nicht gespeicherte Änderungen aus der letzten Sitzung gefunden. Wiederherstellen? (überschreibt den aktuellen Server-Stand)')
				if (restore) state = C.migrate(p.state)
				localStorage.removeItem(PENDING)
			}
			if (!r.j.data && !restore) {
				const old = localStorage.getItem('abiturplaner.v1')
				if (old && confirm('In diesem Browser liegen Noten aus der lokalen Version. Auf den Server übernehmen?')) {
					state = C.migrate(JSON.parse(old))
					restore = true
				}
			}
		} catch (e) { /* ignorieren */ }
		if (restore) changed()
	}

	window.addEventListener('pagehide', () => {
		if (timer) save(true)
	})
	document.addEventListener('visibilitychange', () => {
		if (document.visibilityState === 'hidden' && timer) save(true)
	})

	// ---------- Anmeldung ----------
	function showLogin(msg) {
		const reg = mode === 'reg'
		root.innerHTML = `<div class="abi-login">
			<h2>Abiturplaner</h2>
			<p class="abi-hint">Melde dich an, um deine Noten zu sehen. Sie werden unter deinem Konto auf dem Server gespeichert.</p>
			${regOpen ? `<nav class="abi-tabs"><button class="${reg ? '' : 'on'}" data-act="lmode" data-m="login">Anmelden</button><button class="${reg ? 'on' : ''}" data-act="lmode" data-m="reg">Registrieren</button></nav>` : ''}
			<form class="abi-lf" data-form="${reg ? 'reg' : 'login'}">
				<label>Benutzername<input name="username" autocomplete="username" autocapitalize="none" spellcheck="false" required></label>
				<label>Passwort${reg ? ' (mindestens 10 Zeichen)' : ''}<input name="password" type="password" autocomplete="${reg ? 'new-password' : 'current-password'}" required></label>
				${reg ? '<label>Einladungscode<input name="invite" autocomplete="off" required></label>' : ''}
				<p class="abi-fail" id="lerr">${esc(msg || '')}</p>
				<button class="primary" type="submit">${reg ? 'Konto erstellen' : 'Anmelden'}</button>
			</form></div>`
	}

	root.addEventListener('submit', async (e) => {
		const f = e.target.closest('form[data-form]')
		if (!f) return
		e.preventDefault()
		const btn = f.querySelector('button[type=submit]')
		btn.disabled = true
		try {
			const r = await api(f.dataset.form === 'reg' ? 'register' : 'login', Object.fromEntries(new FormData(f).entries()))
			if (!r.ok) {
				$('#lerr').textContent = r.j.error || 'Fehler (' + r.status + ')'
				btn.disabled = false
				return
			}
			user = r.j.user
			await loadData()
			render()
		} catch (err) {
			const el = $('#lerr')
			if (el) el.textContent = 'Anmeldung fehlgeschlagen: ' + err.message
			btn.disabled = false
		}
	})

	async function boot() {
		root.textContent = 'Lade …'
		try {
			const cfg = await api('config')
			if (!cfg.ok || !('register' in cfg.j)) throw new Error(cfg.j.error || 'api.php wird nicht als PHP ausgeführt (HTTP ' + cfg.status + ')')
			regOpen = !!cfg.j.register
			const me = await api('me')
			if (me.status === 401) {
				showLogin()
				return
			}
			if (!me.ok || !me.j.user) throw new Error(me.j.error || 'Ungültige Antwort (HTTP ' + me.status + ')')
			user = me.j.user
			await loadData()
			render()
		} catch (e) {
			root.innerHTML = `<div class="abi-login"><p class="abi-fail">Der Server ist nicht erreichbar oder nicht eingerichtet:<br>${esc(e.message)}</p><button data-act="reload">Erneut versuchen</button></div>`
		}
	}

	// ---------- Ansichten ----------
	const TABS = [['home', 'Übersicht'], ['kurse', 'Kurse & Noten'], ['abitur', 'Abiturprüfung'], ['opt', 'Optimierer'], ['setup', 'Einrichtung']]

	function render() {
		root.innerHTML = `
			<div class="abi-top">
				<h2>Abiturplaner</h2>
				<nav class="abi-tabs">${TABS.map(([k, t]) => `<button class="${view === k ? 'on' : ''}" data-act="tab" data-v="${k}">${t}</button>`).join('')}</nav>
				<span id="sv" class="abi-sv"></span>
				<span class="abi-user">${esc(user)} <button data-act="logout">Abmelden</button></span>
			</div>
			<div id="vw">${{ home, kurse, abitur, opt: optimizer, setup }[view]()}</div>
			<p class="abi-foot">Deine Noten liegen unter deinem Konto auf dem Server. Der Betreiber des Servers kann sie technisch einsehen. Eine eigene Sicherung (Einrichtung → Daten) ist trotzdem sinnvoll.</p>
			<div id="modal"></div>`
		renderModal()
		live()
	}

	function card(label, big, sub) {
		return `<div class="abi-card"><div class="abi-lbl">${label}</div><div class="abi-big">${big}</div><div class="abi-sub">${sub}</div></div>`
	}

	function home() {
		const g = C.gesamt(state)
		const tag = g.final ? 'Endergebnis' : 'Hochrechnung'
		const tgt = state.settings.target
		const need = C.minPointsForNote(tgt)
		const needII = need - (g.b1.result ?? 0)
		let zielText = ''
		if (g.b1.result == null) zielText = 'Trage zuerst Noten ein.'
		else if (needII > 300) zielText = `Mit der aktuellen Block-I-Hochrechnung (${g.b1.result}) ist ${C.fmt(tgt)} rechnerisch nicht mehr erreichbar.`
		else {
			const n2 = Math.max(100, needII)
			zielText = `Du brauchst insgesamt <b>${need}</b> Punkte. Bei ${g.b1.result} Punkten in Block I sind das <b>${n2}</b> in Block II – im Schnitt <b>${C.fmt(n2 / 20)}</b> Notenpunkte pro Prüfung.`
		}
		const opts = []
		for (let n = 10; n <= 40; n++) opts.push(`<option value="${n / 10}" ${Math.round(tgt * 10) === n ? 'selected' : ''}>${C.fmt(n / 10)}</option>`)
		return `
			<div class="abi-grid">
				${card('Abiturnote', g.note == null ? '–' : C.fmt(g.note), `${g.total ?? '–'} von 900 Punkten · ${tag}`)}
				${card('Block I – Kurse', g.b1.result ?? '–', `von 600 · ${g.b1.nKnown}/${g.b1.count} Kurse bewertet`)}
				${card('Block II – Prüfung', g.b2.total, `von 300 · ${g.b2.complete ? 'alle Prüfungen eingetragen' : 'fehlende Prüfungen geschätzt'}`)}
				${card('Status', g.passed ? 'im Soll' : 'prüfen', g.final ? 'endgültig' : 'vorläufig')}
			</div>
			<div class="abi-two">
				<section><h3>Block I – Zulassung</h3>${checks(g.b1.checks)}</section>
				<section><h3>Block II – Abiturprüfung</h3>${checks(g.b2.checks)}</section>
			</div>
			<section class="abi-goal"><h3>Zielnote</h3>
				<label>Ich möchte mindestens <select data-a="target">${opts.join('')}</select> erreichen.</label>
				<p>${zielText}</p>
			</section>`
	}

	function kurse() {
		const b = C.blockI(state)
		const rows = state.fachs.map((f) => {
			const cells = [0, 1, 2, 3].map((h) => {
				if (f.hjActive[h] === false) return '<td class="abi-na">–</td>'
				const c = b.all.find((x) => x.fach === f && x.hj === h)
				const used = b.chosen.has(c)
				const p = c.pts
				return `<td><button class="abi-cell ${cls(p)} ${used ? 'used' : 'unused'}" data-act="edit" data-f="${f.id}" data-h="${h}" title="${used ? 'wird angerechnet' : 'wird nicht angerechnet'}">${p == null ? '<span class="abi-plus">+</span>' : `<b>${p}</b><small>${C.noteLabel(p)}</small>`}</button></td>`
			}).join('')
			const badge = C.isLF(f) ? `LF${b.dbl.has(f.id) ? ' ×2' : ''}` : f.pruefung === 'm' ? 'mündl.' : ''
			const avg = C.avg(b.all.filter((c) => c.fach === f && c.pts != null).map((c) => c.pts))
			return `<tr><th>${esc(f.name)}${badge ? ` <span class="abi-badge">${badge}</span>` : ''}${f.gfs ? ' <span class="abi-badge gfs">GFS ' + C.HJ[f.gfsHj] + '</span>' : ''}</th>${cells}<td class="abi-avg">${C.fmt(avg)}</td></tr>`
		}).join('')
		return `
			<p class="abi-hint">Klicke auf ein Halbjahr, um Klassenarbeiten, GFS und mündliche Noten einzutragen. <b>Kräftig</b> dargestellte Kurse werden in Block I angerechnet, <b>blasse</b> nicht (die App wählt automatisch die günstigste erlaubte Kombination aus 40 Kursen).</p>
			<div class="abi-scroll"><table class="abi-t">
				<thead><tr><th>Fach</th>${C.HJ.map((h) => `<th>${h}</th>`).join('')}<th>Ø</th></tr></thead>
				<tbody>${rows || '<tr><td colspan="6">Noch keine Fächer – siehe „Einrichtung“.</td></tr>'}</tbody>
			</table></div>
			<section><h3>Block I: ${b.result ?? '–'} / 600 ${b.complete ? '' : '(Hochrechnung)'}</h3>${checks(b.checks)}</section>`
	}

	function abitur() {
		const pf = C.pruefFaecher(state)
		if (!pf.length) return '<p>Wähle zuerst in der Einrichtung Fächer aus.</p>'
		const inp = (f, k, label) => `<label>${label}<input type="number" min="0" max="15" inputmode="numeric" data-a="pr" data-f="${f.id}" data-k="${k}" value="${(state.pruefung[f.id] || {})[k] ?? ''}"></label>`
		const blocks = pf.map((f) => {
			let fields = ''
			if (C.isLF(f)) {
				fields += inp(f, 's', 'Schriftlich (Punkte)')
				if (f.modernFS) fields += inp(f, 'k', 'Kommunikationsprüfung (zählt 1/3)')
				if (f.praktisch) fields += inp(f, 'f', 'Fachpraktisch (Anteil 1:1)')
				fields += inp(f, 'm', 'Zusätzl. mündliche Prüfung (optional, 1/3)')
			} else {
				fields += inp(f, 'm', 'Mündlich (Punkte)')
				if (f.praktisch) fields += inp(f, 'f', 'Fachpraktisch (zählt doppelt)')
			}
			return `<section class="abi-pf"><h3>${esc(f.name)} <span class="abi-badge">${C.isLF(f) ? 'schriftlich (LF)' : 'mündlich'}</span></h3><div class="abi-form">${fields}</div></section>`
		}).join('')
		return `<p class="abi-hint">Trage Prüfungsergebnisse (0–15 Punkte) ein. Fehlende Prüfungen werden mit deinem Schnitt im Fach geschätzt – du kannst auch Wunschwerte eintragen, um zu simulieren.</p>
			<div class="abi-two"><div>${blocks}</div><div><div id="live" class="abi-sticky"></div></div></div>`
	}

	function abiLive() {
		const g = C.gesamt(state)
		const rows = g.b2.rows.map((r) => `<tr><td>${esc(r.fach.name)}</td><td>${r.pts ?? '–'}${r.est ? ' <small>(geschätzt)</small>' : ''}</td><td><b>${r.block ?? '–'}</b></td></tr>`).join('')
		return `<table class="abi-t"><thead><tr><th>Prüfung</th><th>Notenpunkte</th><th>× 4</th></tr></thead><tbody>${rows}</tbody>
			<tfoot><tr><th colspan="2">Block II</th><th>${g.b2.total} / 300</th></tr></tfoot></table>
			${checks(g.b2.checks)}
			<div class="abi-card"><div class="abi-lbl">Gesamt ${g.final ? '' : '(vorläufig)'}</div><div class="abi-big">${g.total ?? '–'} <small>/ 900</small></div><div class="abi-sub">Abiturnote ${g.note == null ? '–' : C.fmt(g.note)}</div></div>`
	}

	function optimizer() {
		const g = C.gesamt(state)
		if (g.b1.result == null) return '<p class="abi-hint">Trage zuerst einige Noten unter „Kurse &amp; Noten“ ein, dann kann ich optimieren.</p>'
		const o = C.optimizePruefung(state)
		const dp = C.doublePairs(state)
		const sens = C.sensitivity(state)
		const delta = state.settings.examDelta || 0
		const dOpts = [-3, -2, -1, 0, 1, 2].map((d) => `<option value="${d}" ${d === delta ? 'selected' : ''}>${d === 0 ? 'wie Kursschnitt' : (d > 0 ? '+' : '') + d + ' Punkte'}</option>`).join('')
		const nt = (r) => (r.note == null ? '–' : C.fmt(r.note))
		const cur = o.rows.find((r) => r.current)
		const best = o.rows[0]
		let pf = ''
		if (!o.rows.length) {
			pf = `<p class="abi-hint">Mit ${state.fachs.filter(C.isLF).length} Leistungsfächern ist keine Kombination berechenbar (3 Leistungsfächer + 2 mündliche Fächer erwartet).</p>`
		} else {
			const gain = cur && best ? best.total - cur.total : null
			const head = !cur
				? `Du hast noch keine passenden mündlichen Prüfungsfächer gewählt. Die beste Kombination wäre <b>${esc(best.names.join(' + '))}</b> mit ca. <b>${best.total}</b> Punkten (Note ${nt(best)}).`
				: gain > 0
					? `Deine aktuelle Wahl (<b>${esc(cur.names.join(' + '))}</b>) ergibt ca. ${cur.total} Punkte. Mit <b>${esc(best.names.join(' + '))}</b> wären es <b>+${gain} Punkte</b> (Note ${nt(cur)} → ${nt(best)}).`
					: `Deine aktuelle Wahl (<b>${esc(cur.names.join(' + '))}</b>) ist bereits die beste Kombination.`
			const rows = o.rows.slice(0, 7).map((r, i) => `<tr class="${r.current ? 'abi-cur' : ''}"><td>${i + 1}</td><td>${esc(r.names.join(' + '))}${r.current ? ' <span class="abi-badge">aktuell</span>' : ''}${r.valid ? '' : ' <span class="abi-badge bad">regelwidrig</span>'}</td><td>${r.b1}</td><td>${r.b2}</td><td><b>${r.total ?? '–'}</b></td><td>${nt(r)}</td><td>${r.current ? '' : `<button data-act="applyPf" data-ids="${r.ids.join(',')}">übernehmen</button>`}</td></tr>`).join('')
			pf = `<p>${head}</p><div class="abi-scroll"><table class="abi-t"><thead><tr><th>#</th><th>Mündliche Prüfungsfächer</th><th>Block I</th><th>Block II</th><th>Gesamt</th><th>Note</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>
				<p class="abi-hint">${o.invalid} weitere Kombination(en) wurden ausgeschlossen, weil sie gegen Regeln verstoßen (z. B. Aufgabenfelder nicht abgedeckt).</p>`
		}
		const dRows = dp.map((r) => `<tr class="${r.current ? 'abi-cur' : ''}"><td>${esc(r.names.join(' + '))}${r.current ? ' <span class="abi-badge">aktuell</span>' : ''}</td><td>${r.b1}</td><td>${r.total ?? '–'}</td><td>${r.current ? '' : `<button data-act="applyDbl" data-ids="${r.ids.join(',')}">festlegen</button>`}</td></tr>`).join('')
		const autoNote = state.settings.autoDouble !== false ? 'Aktuell wählt die App automatisch das beste Paar.' : '<button data-act="autoDbl">Wieder automatisch wählen</button>'
		const sRows = sens.slice(0, 6).map((r) => `<tr><td>${esc(r.fach.name)}${C.isLF(r.fach) ? ' <span class="abi-badge">LF</span>' : ''}</td><td><b>${r.delta >= 0 ? '+' : ''}${r.delta}</b></td><td>${nt(r)}</td></tr>`).join('')
		return `
			<p class="abi-hint">Der Optimierer rechnet alle regelkonformen Möglichkeiten durch. Noch fehlende Prüfungsnoten werden aus dem Kursschnitt des Fachs geschätzt. Bereits eingetragene Prüfungsergebnisse zählen exakt. Es ist eine Entscheidungshilfe – Wahlfristen und Vorgaben deiner Schule gelten.</p>
			<section class="abi-bar"><label>Meine Prüfungsnoten erwarte ich im Vergleich zum Kursschnitt: <select data-a="delta">${dOpts}</select></label></section>
			<h3>1 · Mündliche Prüfungsfächer</h3>${pf}
			<h3>2 · Doppelt gewertete Leistungsfächer</h3>
			${dp.length ? `<div class="abi-scroll"><table class="abi-t"><thead><tr><th>Doppelt zählen</th><th>Block I</th><th>Gesamt</th><th></th></tr></thead><tbody>${dRows}</tbody></table></div><p class="abi-hint">${autoNote}</p>` : '<p class="abi-hint">Mindestens 2 Leistungsfächer nötig.</p>'}
			<h3>3 · Wo lohnt sich Lernaufwand am meisten?</h3>
			<p class="abi-hint">Wirkung von <b>+1 Punkt</b> in allen bereits bewerteten Kursen eines Fachs auf die Gesamtpunktzahl (inkl. geschätzter Prüfung).</p>
			${sens.length ? `<div class="abi-scroll"><table class="abi-t"><thead><tr><th>Fach</th><th>Gesamtpunkte</th><th>Neue Note</th></tr></thead><tbody>${sRows}</tbody></table></div>` : '<p class="abi-hint">Noch keine bewerteten Kurse.</p>'}`
	}

	function setup() {
		const auto = state.settings.autoDouble !== false
		const catalog = C.KATALOG.map((k, i) => `<option value="${i}">${esc(k.name)}</option>`).join('') + '<option value="-1">Eigenes Fach …</option>'
		return `
			<div class="abi-two">
				<div>
					<section class="abi-bar">
						<label class="chk"><input type="checkbox" data-a="auto2" data-r="1" ${auto ? 'checked' : ''}> Doppelt gewertete Leistungsfächer automatisch wählen (die beiden mit den meisten Punkten)</label>
						<div class="abi-add"><select id="addsel">${catalog}</select><button class="primary" data-act="addf">Fach hinzufügen</button></div>
					</section>
					${state.fachs.map((f) => fachCard(f, auto)).join('')}
					<section class="abi-bar">
						<h3>Konto: ${esc(user)}</h3>
						<div class="abi-form">
							<label>Aktuelles Passwort<input id="pw-old" type="password" autocomplete="current-password"></label>
							<label>Neues Passwort (mindestens 10 Zeichen)<input id="pw-new" type="password" autocomplete="new-password"></label>
						</div>
						<button data-act="passwd">Passwort ändern</button> <span id="pw-msg" class="abi-hint"></span>
					</section>
					<section class="abi-bar">
						<h3>Daten</h3>
						<button data-act="export">Als JSON sichern</button>
						<label class="abi-file">Aus JSON wiederherstellen<input type="file" accept="application/json" data-a="import"></label>
						<button class="danger" data-act="reset">Alles zurücksetzen</button>
					</section>
				</div>
				<div><div id="live" class="abi-sticky"></div></div>
			</div>`
	}

	function fachCard(f, auto) {
		const lf = C.isLF(f)
		const d = `data-a="fset" data-f="${f.id}"`
		const sel = (k, opts, cur, extra = '') => `<select ${d} data-k="${k}" ${extra}>${opts.map(([v, t]) => `<option value="${v}" ${String(cur) === String(v) ? 'selected' : ''}>${t}</option>`).join('')}</select>`
		const chk = (k, label, extra = '') => `<label class="chk"><input type="checkbox" ${d} data-k="${k}" data-t="bool" ${extra} ${f[k] ? 'checked' : ''}> ${label}</label>`
		const num = (k, label, min, max) => `<label>${label}<input type="number" min="${min}" max="${max}" ${d} data-k="${k}" data-t="int" value="${f[k]}"></label>`
		return `<section class="abi-fach">
			<header><input class="abi-name" ${d} data-k="name" value="${esc(f.name)}" aria-label="Fachname"><button class="abi-x" data-act="delf" data-f="${f.id}" title="Fach entfernen">✕</button></header>
			<div class="abi-form">
				<label>Fachart ${sel('type', [['LF', 'Leistungsfach (5-stündig)'], ['BF', 'Basisfach']], f.type, 'data-r="1"')}</label>
				${lf ? '' : `<label>Abiturprüfung ${sel('pruefung', [['', 'keine'], ['m', 'mündlich']], f.pruefung)}</label>`}
				<label>Aufgabenfeld ${sel('area', [[0, 'ohne'], [1, 'I Sprachlich'], [2, 'II Gesellschaft'], [3, 'III Mathe/Naturwiss.']], f.area, 'data-t="int"')}</label>
				<label>Schriftlich-Anteil (%) <input type="number" min="0" max="100" ${d} data-k="wS" data-t="int" value="${f.wS}"><small data-mu>mündlich: ${100 - f.wS} %</small></label>
				${num('nArb', 'Klassenarbeiten pro Halbjahr', 0, 8)}
				${num('nMu', 'Mündliche Noten pro Halbjahr', 0, 12)}
				${lf ? '' : num('minAnr', 'Mind. anzurechnende Kurse', 0, 4)}
				<div>${chk('gfs', 'GFS in diesem Fach', 'data-r="1"')}${f.gfs ? `<label>im Halbjahr ${sel('gfsHj', C.HJ.map((h, i) => [i, h]), f.gfsHj, 'data-t="int"')}</label>` : ''}</div>
				<div>${chk('modernFS', 'Moderne Fremdsprache (Kommunikationsprüfung)', 'data-r="1"')}${chk('praktisch', 'Fachpraktische Anteile (BK/Mu/Sport)', 'data-r="1"')}${lf && !auto ? chk('double', 'Doppelt gewertet') : ''}</div>
				<fieldset><legend>Belegte Halbjahre</legend>${C.HJ.map((h, i) => `<label class="chk"><input type="checkbox" data-a="hja" data-f="${f.id}" data-h="${i}" ${f.hjActive[i] ? 'checked' : ''}> ${h}</label>`).join('')}</fieldset>
			</div>
		</section>`
	}

	function setupLive() {
		return `<h3>Prüfung der Einrichtung</h3>${checks(C.setupChecks(state))}<p class="abi-hint">Abgleich mit den Regeln für Belegung, Anrechnung und Prüfungsfächer. Maßgeblich bleiben immer die Vorgaben deiner Schule und der aktuelle Leitfaden des Kultusministeriums.</p>`
	}

	// ---------- Dialog für ein Halbjahr ----------
	function renderModal() {
		const m = $('#modal')
		if (!m) return
		if (!modal) {
			m.innerHTML = ''
			return
		}
		const f = fach(modal.f)
		const h = modal.h
		const k = kurs(f.id, h)
		while (k.arb.length < f.nArb) k.arb.push(null)
		while (k.mu.length < f.nMu) k.mu.push(null)
		const gfsHere = f.gfs && f.gfsHj === h
		const list = (kind) => k[kind].map((v, i) => `<input type="number" min="0" max="15" inputmode="numeric" data-a="${kind}" data-i="${i}" value="${v ?? ''}" placeholder="Pkt." aria-label="${kind === 'arb' ? 'Klassenarbeit' : 'Mündliche Note'} ${i + 1}">`).join('')
		m.innerHTML = `<div class="abi-back" data-act="closeBg"><div class="abi-dialog" role="dialog" aria-modal="true">
			<h3>${esc(f.name)} · Halbjahr ${C.HJ[h]}</h3>
			<div class="abi-cols">
				<div><h4>Klassenarbeiten${gfsHere ? ' &amp; GFS' : ''} <small>${f.wS} %</small></h4>
					<div class="abi-inputs">${list('arb')}</div>
					<button data-act="add" data-kind="arb">+ Arbeit</button>
					${gfsHere ? `<label class="abi-gfs">GFS (zählt wie eine Klassenarbeit)<input type="number" min="0" max="15" data-a="gfs" value="${k.gfs ?? ''}" placeholder="Pkt."></label>` : ''}
				</div>
				<div><h4>Mündliche Noten <small>${100 - f.wS} %</small></h4>
					<div class="abi-inputs">${list('mu')}</div>
					<button data-act="add" data-kind="mu">+ Note</button>
				</div>
			</div>
			<div class="abi-form">
				<label>Halbjahresnote laut Zeugnis (überschreibt die Berechnung)<input type="number" min="0" max="15" data-a="ovr" value="${k.override ?? ''}" placeholder="leer = berechnet"></label>
				<label>Anrechnung in Block I<select data-a="incl"><option value="auto" ${k.include == null ? 'selected' : ''}>automatisch</option><option value="1" ${k.include === true ? 'selected' : ''}>immer anrechnen</option><option value="0" ${k.include === false ? 'selected' : ''}>nicht anrechnen</option></select></label>
			</div>
			<div id="live"></div>
			<div class="abi-actions"><button class="primary" data-act="close">Fertig</button></div>
		</div></div>`
	}

	function modalLive() {
		const f = fach(modal.f)
		const k = kurs(f.id, modal.h)
		const r = C.hjResult(f, k, modal.h)
		const b = C.blockI(state)
		const c = b.all.find((x) => x.fach === f && x.hj === modal.h)
		const parts = [`Schriftlich Ø ${C.fmt(r.s, 2)}`, `Mündlich Ø ${C.fmt(r.m, 2)}`]
		return `<div class="abi-card"><div class="abi-sub">${parts.join(' · ')}${r.raw != null ? ` → ${C.fmt(r.raw, 2)}` : ''}</div>
			<div class="abi-big">${r.final == null ? '–' : r.final + ' Punkte'} <small>${C.noteLabel(r.final)}${k.override != null ? ' · Zeugnis' : ''}</small></div>
			<div class="abi-sub">${b.chosen.has(c) ? 'Dieser Kurs wird in Block I angerechnet.' : 'Dieser Kurs wird aktuell nicht angerechnet.'}</div></div>`
	}

	function live() {
		const el = $('#live')
		if (!el) return
		el.innerHTML = modal ? modalLive() : view === 'abitur' ? abiLive() : view === 'setup' ? setupLive() : ''
	}

	// ---------- Ereignisse ----------
	function onInput(t, isChange) {
		const a = t.dataset.a
		let redraw = false
		switch (a) {
		case 'arb':
		case 'mu':
			kurs(modal.f, modal.h)[a][+t.dataset.i] = pts(t.value)
			break
		case 'gfs':
			kurs(modal.f, modal.h).gfs = pts(t.value)
			break
		case 'ovr':
			kurs(modal.f, modal.h).override = pts(t.value)
			break
		case 'incl': {
			const k = kurs(modal.f, modal.h)
			if (t.value === 'auto') delete k.include
			else k.include = t.value === '1'
			break
		}
		case 'pr': {
			const p = (state.pruefung[t.dataset.f] = state.pruefung[t.dataset.f] || {})
			p[t.dataset.k] = pts(t.value)
			break
		}
		case 'fset': {
			const f = fach(t.dataset.f)
			const k = t.dataset.k
			const ty = t.dataset.t
			f[k] = ty === 'bool' ? t.checked : ty === 'int' ? int(t.value, k === 'wS' ? 0 : 0, k === 'wS' ? 100 : 12) : t.value
			if (k === 'wS') {
				const s = t.closest('label').querySelector('[data-mu]')
				if (s) s.textContent = `mündlich: ${100 - f.wS} %`
			}
			if (k === 'type' && t.value === 'LF') f.pruefung = ''
			break
		}
		case 'hja':
			fach(t.dataset.f).hjActive[+t.dataset.h] = t.checked
			break
		case 'auto2':
			state.settings.autoDouble = t.checked
			break
		case 'delta':
			state.settings.examDelta = Number(t.value)
			redraw = true
			break
		case 'target':
			state.settings.target = Number(t.value)
			redraw = true
			break
		case 'import': {
			const file = t.files && t.files[0]
			if (!file) return
			file.text().then((txt) => {
				try {
					state = C.migrate(JSON.parse(txt))
					changed()
					render()
				} catch (e) {
					alert('Die Datei konnte nicht gelesen werden.')
				}
			})
			return
		}
		default:
			return
		}
		changed()
		if (isChange && (t.dataset.r || redraw)) render()
		else live()
	}

	function act(name, t, ev) {
		switch (name) {
		case 'tab':
			view = t.dataset.v
			modal = null
			render()
			break
		case 'edit':
			modal = { f: t.dataset.f, h: +t.dataset.h }
			renderModal()
			live()
			break
		case 'closeBg':
			if (ev.target !== t) return
			// fallthrough
		case 'close':
			modal = null
			render()
			break
		case 'add': {
			const k = kurs(modal.f, modal.h)
			k[t.dataset.kind].push(null)
			renderModal()
			live()
			changed()
			break
		}
		case 'addf': {
			const i = +$('#addsel').value
			const base = i >= 0 ? C.KATALOG[i] : { name: 'Neues Fach', area: 0 }
			state.fachs.push(C.newFach(base))
			changed()
			render()
			break
		}
		case 'delf':
			if (confirm('Dieses Fach samt aller Noten entfernen?')) {
				const id = t.dataset.f
				state.fachs = state.fachs.filter((f) => f.id !== id)
				delete state.kurse[id]
				delete state.pruefung[id]
				changed()
				render()
			}
			break
		case 'applyPf': {
			const ids = t.dataset.ids.split(',')
			state.fachs.forEach((f) => {
				if (!C.isLF(f)) f.pruefung = ids.includes(f.id) ? 'm' : ''
			})
			changed()
			render()
			break
		}
		case 'applyDbl': {
			const ids = t.dataset.ids.split(',')
			state.settings.autoDouble = false
			state.fachs.forEach((f) => {
				f.double = ids.includes(f.id)
			})
			changed()
			render()
			break
		}
		case 'autoDbl':
			state.settings.autoDouble = true
			changed()
			render()
			break
		case 'lmode':
			mode = t.dataset.m
			showLogin()
			break
		case 'reload':
			boot()
			break
		case 'logout':
			;(async () => {
				if (timer) await save()
				try {
					await api('logout', {})
				} catch (e) { /* ignorieren */ }
				user = null
				state = null
				modal = null
				view = 'home'
				localStorage.removeItem(PENDING)
				showLogin()
			})()
			break
		case 'passwd':
			;(async () => {
				const msg = $('#pw-msg')
				try {
					const r = await api('passwd', { old: $('#pw-old').value, new: $('#pw-new').value })
					msg.textContent = r.ok ? 'Passwort geändert. Andere Geräte wurden abgemeldet.' : (r.j.error || 'Fehler')
					if (r.ok) {
						$('#pw-old').value = ''
						$('#pw-new').value = ''
					}
				} catch (e) {
					msg.textContent = 'Server nicht erreichbar'
				}
			})()
			break
		case 'export': {
			const a = document.createElement('a')
			a.href = URL.createObjectURL(new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' }))
			a.download = 'abiturplaner-backup.json'
			a.click()
			URL.revokeObjectURL(a.href)
			break
		}
		case 'reset':
			if (confirm('Wirklich ALLE Fächer, Noten und Prüfungen löschen und die Standardvorlage laden?')) {
				state = C.defaultState()
				changed()
				render()
			}
			break
		}
	}

	root.addEventListener('click', (e) => {
		const t = e.target.closest('[data-act]')
		if (t) act(t.dataset.act, t, e)
	})
	root.addEventListener('input', (e) => {
		if (e.target.dataset && e.target.dataset.a && e.target.type !== 'checkbox' && e.target.tagName !== 'SELECT' && e.target.type !== 'file') onInput(e.target, false)
	})
	root.addEventListener('change', (e) => {
		if (e.target.dataset && e.target.dataset.a) onInput(e.target, true)
	})
	document.addEventListener('keydown', (e) => {
		if (e.key === 'Escape' && modal) {
			modal = null
			render()
		}
	})

	// ---------- Start ----------
	boot()
	if ('serviceWorker' in navigator && location.protocol !== 'file:') navigator.serviceWorker.register('./sw.js').catch(() => {})
})()
