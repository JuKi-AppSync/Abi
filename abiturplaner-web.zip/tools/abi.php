<?php

/**
 * Abiturplaner – Verwaltung auf dem Server (nur Kommandozeile).
 *
 *   sudo -u www-data php tools/abi.php init
 *   sudo -u www-data php tools/abi.php adduser <name>
 *   sudo -u www-data php tools/abi.php passwd <name>
 *   sudo -u www-data php tools/abi.php deluser <name>
 *   sudo -u www-data php tools/abi.php list
 *   sudo -u www-data php tools/abi.php backup [zielordner]
 *
 * Passwort wird abgefragt (oder über die Umgebungsvariable ABI_PASSWORD übergeben).
 */

if (PHP_SAPI !== 'cli') {
	http_response_code(404);
	exit;
}
define('ABI_CLI', true);
require __DIR__ . '/../api.php';

function say(string $s): void {
	fwrite(STDOUT, $s . PHP_EOL);
}

function die_with(string $s): void {
	fwrite(STDERR, 'Fehler: ' . $s . PHP_EOL);
	exit(1);
}

function ask_password(string $label): string {
	$env = getenv('ABI_PASSWORD');
	if ($env !== false && $env !== '') {
		return $env;
	}
	fwrite(STDOUT, $label);
	@shell_exec('stty -echo');
	$p = rtrim((string)fgets(STDIN), "\r\n");
	@shell_exec('stty echo');
	fwrite(STDOUT, PHP_EOL);
	return $p;
}

$cmd = $argv[1] ?? 'help';
$name = isset($argv[2]) ? abi_norm_user($argv[2]) : '';

try {
	switch ($cmd) {
	case 'init':
		$dir = abi_dir();
		if (!is_dir($dir) && !mkdir($dir, 0750, true)) {
			die_with("Verzeichnis $dir konnte nicht angelegt werden (als root anlegen und www-data zuweisen).");
		}
		$cfg = $dir . '/config.php';
		if (!is_file($cfg)) {
			file_put_contents($cfg, "<?php\n\nreturn [\n\t// Selbstregistrierung mit Einladungscode erlauben (Code unten setzen, sonst bleibt sie aus)\n\t'allow_register' => false,\n\t'invite_code' => '',\n\t// true NUR hinter einem Reverse-Proxy, der X-Forwarded-For/-Proto setzt\n\t'trust_proxy' => false,\n];\n");
			chmod($cfg, 0640);
		}
		abi_db();
		say("OK – Datenverzeichnis: $dir");
		say("Konfiguration:      $cfg");
		break;

	case 'adduser':
		if ($name === '') {
			die_with('Benutzername fehlt');
		}
		$pw = ask_password('Passwort (min. ' . ABI_MIN_PW . ' Zeichen): ');
		if (getenv('ABI_PASSWORD') === false && $pw !== ask_password('Passwort wiederholen: ')) {
			die_with('Passwörter stimmen nicht überein');
		}
		abi_create_user($name, $pw);
		say("Benutzer '$name' angelegt.");
		break;

	case 'passwd':
		if ($name === '') {
			die_with('Benutzername fehlt');
		}
		$pw = ask_password('Neues Passwort: ');
		if (abi_len($pw) < ABI_MIN_PW) {
			die_with('mindestens ' . ABI_MIN_PW . ' Zeichen');
		}
		$st = abi_db()->prepare('UPDATE users SET pass = ? WHERE username = ?');
		$st->execute([password_hash($pw, PASSWORD_DEFAULT), $name]);
		if (!$st->rowCount()) {
			die_with('Benutzer nicht gefunden');
		}
		abi_db()->prepare('DELETE FROM sessions WHERE user_id = (SELECT id FROM users WHERE username = ?)')->execute([$name]);
		say('Passwort geändert, alle Sitzungen beendet.');
		break;

	case 'deluser':
		if ($name === '') {
			die_with('Benutzername fehlt');
		}
		$st = abi_db()->prepare('DELETE FROM users WHERE username = ?');
		$st->execute([$name]);
		say($st->rowCount() ? "Benutzer '$name' und alle Daten gelöscht." : 'Benutzer nicht gefunden.');
		break;

	case 'list':
		foreach (abi_db()->query('SELECT u.username, u.created_at, d.version, d.updated_at FROM users u LEFT JOIN docs d ON d.user_id = u.id ORDER BY u.username') as $r) {
			say(sprintf('%-20s angelegt %s | Daten: %s', $r['username'], date('Y-m-d', (int)$r['created_at']), $r['version'] ? 'v' . $r['version'] . ' ' . date('Y-m-d H:i', (int)$r['updated_at']) : 'keine'));
		}
		break;

	case 'backup':
		$out = rtrim($argv[2] ?? (abi_dir() . '/backups'), '/');
		if (!is_dir($out) && !mkdir($out, 0750, true)) {
			die_with("Zielordner $out nicht anlegbar");
		}
		$file = $out . '/abiturplaner-' . date('Y-m-d_His') . '.sqlite';
		abi_db()->exec("VACUUM INTO '" . str_replace("'", "''", $file) . "'");
		chmod($file, 0640);
		// nur die letzten 14 Sicherungen behalten
		$all = glob($out . '/abiturplaner-*.sqlite') ?: [];
		sort($all);
		foreach (array_slice($all, 0, max(0, count($all) - 14)) as $old) {
			unlink($old);
		}
		say("Sicherung: $file");
		break;

	default:
		say("Befehle: init | adduser <name> | passwd <name> | deluser <name> | list | backup [ordner]");
	}
} catch (Throwable $e) {
	die_with($e->getMessage());
}
