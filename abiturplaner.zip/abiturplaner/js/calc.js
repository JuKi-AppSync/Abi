/**
 * Abiturplaner BW – Rechenlogik (ohne UI, auch in Node testbar)
 *
 * Regelgrundlage: Abiturverordnung Gymnasium Baden-Württemberg, Kursstufe
 * (Informationen der Kultusverwaltung / Leitfaden). Alle Parameter sind
 * so gebaut, dass sie in der Einrichtung angepasst werden können.
 *
 * Block I : genau 40 Kurse, 2 der 3 Leistungsfächer doppelt  => Punkte*40/48
 * Block II: 5 Prüfungen, jeweils 4-fach                      => max. 300
 */
(function (root, factory) {
	if (typeof module === 'object' && module.exports) {
		module.exports = factory()
	} else {
		root.AbiCalc = factory()
	}
})(typeof self !== 'undefined' ? self : this, function () {
	'use strict'

	const HJ = ['12/1', '12/2', '13/1', '13/2']
	const NOTE = ['6', '5-', '5', '5+', '4-', '4', '4+', '3-', '3', '3+', '2-', '2', '2+', '1-', '1', '1+']
	const AREA = {
		0: 'ohne Zuordnung',
		1: 'I – sprachlich-literarisch-künstlerisch',
		2: 'II – gesellschaftswissenschaftlich',
		3: 'III – mathematisch-naturwiss.-technisch',
	}

	const KATALOG = [
		{ name: 'Deutsch', area: 1 },
		{ name: 'Englisch', area: 1, modernFS: true },
		{ name: 'Französisch', area: 1, modernFS: true },
		{ name: 'Spanisch', area: 1, modernFS: true },
		{ name: 'Latein', area: 1 },
		{ name: 'Bildende Kunst', area: 1, praktisch: true, minAnr: 2 },
		{ name: 'Musik', area: 1, praktisch: true, minAnr: 2 },
		{ name: 'Literatur', area: 1 },
		{ name: 'Geschichte', area: 2 },
		{ name: 'Geographie', area: 2 },
		{ name: 'Gemeinschaftskunde', area: 2 },
		{ name: 'Ethik', area: 2 },
		{ name: 'Evangelische Religion', area: 2 },
		{ name: 'Katholische Religion', area: 2 },
		{ name: 'Philosophie', area: 2 },
		{ name: 'Psychologie', area: 2 },
		{ name: 'Mathematik', area: 3 },
		{ name: 'Biologie', area: 3 },
		{ name: 'Chemie', area: 3 },
		{ name: 'Physik', area: 3 },
		{ name: 'Informatik', area: 3 },
		{ name: 'Sport', area: 0, praktisch: true },
	]

	// ---------- Hilfsfunktionen ----------
	const roundHalfUp = (x) => Math.floor(x + 0.5 + 1e-9)
	const clamp = (p) => Math.max(0, Math.min(15, p))
	const noteLabel = (p) => (p == null ? '–' : NOTE[p])
	const isLF = (f) => f.type === 'LF'
	const fmt = (n, d = 1) => (n == null ? '–' : Number(n).toFixed(d).replace('.', ','))
	function avg(list) {
		const v = list.filter((x) => x != null && !Number.isNaN(x))
		return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null
	}
	const uid = () => 'f' + Math.random().toString(36).slice(2, 9)

	// ---------- Vorlagen ----------
	function newFach(base, over) {
		return Object.assign({
			id: uid(),
			name: base.name,
			type: 'BF', // 'LF' = Leistungsfach (5-stündig), 'BF' = Basisfach
			area: base.area ?? 0,
			pruefung: '', // nur Basisfach: '' oder 'm' (mündliches Prüfungsfach)
			modernFS: !!base.modernFS, // Kommunikationsprüfung (2/3 schriftlich, 1/3 Komm.)
			praktisch: !!base.praktisch, // fachpraktische Anteile (BK, Mu, Sport)
			wS: 50, // Anteil schriftlich in % (Rest = mündlich)
			nArb: 1, // geplante Klassenarbeiten pro Halbjahr
			nMu: 3, // geplante mündliche Noten pro Halbjahr
			gfs: false,
			gfsHj: 0, // Halbjahr der GFS (0..3)
			minAnr: base.minAnr ?? 4, // Mindestanzahl anzurechnender Kurse (Anrechnungspflicht)
			double: false, // nur bei manueller Wahl der doppelten LF
			hjActive: [true, true, true, true],
		}, over || {})
	}

	function defaultState() {
		const k = (n) => KATALOG.find((x) => x.name === n)
		const lf = { type: 'LF', nArb: 2 }
		const fachs = [
			newFach(k('Deutsch'), lf),
			newFach(k('Mathematik'), lf),
			newFach(k('Englisch'), lf),
			newFach(k('Biologie')),
			newFach(k('Physik')),
			newFach(k('Geschichte')),
			newFach(k('Geographie'), { hjActive: [true, false, true, false], minAnr: 2 }),
			newFach(k('Gemeinschaftskunde'), { hjActive: [false, true, false, true], minAnr: 2 }),
			newFach(k('Ethik')),
			newFach(k('Bildende Kunst')),
			newFach(k('Sport')),
		]
		return { version: 1, settings: { autoDouble: true, target: 2.0 }, fachs, kurse: {}, pruefung: {} }
	}

	function migrate(d) {
		const base = defaultState()
		const st = Object.assign({}, base, d)
		st.settings = Object.assign({}, base.settings, d.settings || {})
		st.kurse = d.kurse || {}
		st.pruefung = d.pruefung || {}
		st.fachs = (d.fachs || []).map((f) => Object.assign(newFach({ name: f.name || 'Fach' }), f))
		st.fachs.forEach((f) => {
			if (!Array.isArray(f.hjActive) || f.hjActive.length !== 4) f.hjActive = [true, true, true, true]
		})
		return st
	}

	// ---------- Halbjahresnote ----------
	function hjResult(f, k, idx) {
		k = k || {}
		const gfsHere = f.gfs && f.gfsHj === idx && k.gfs != null ? [k.gfs] : []
		const s = avg([...(k.arb || []), ...gfsHere]) // GFS zählt wie eine Klassenarbeit
		const m = avg(k.mu || [])
		let raw = null
		if (s != null && m != null) {
			const w = (f.wS ?? 50) / 100
			raw = w * s + (1 - w) * m
		} else {
			raw = s != null ? s : m
		}
		const calc = raw == null ? null : clamp(roundHalfUp(raw))
		const fin = k.override != null ? k.override : calc
		return { s, m, raw, calc, final: fin }
	}

	function allCourses(st) {
		const out = []
		st.fachs.forEach((f) => {
			for (let h = 0; h < 4; h++) {
				if (f.hjActive[h] === false) continue
				const k = (st.kurse[f.id] || [])[h] || {}
				const res = hjResult(f, k, h)
				out.push({ fach: f, hj: h, res, pts: res.final, include: k.include })
			}
		})
		return out
	}

	// ---------- Block I ----------
	function selectCourses(all) {
		const pool = all.filter((c) => c.include !== false)
		const chosen = new Set(all.filter((c) => c.include === true))
		const byFach = new Map()
		pool.forEach((c) => {
			if (!byFach.has(c.fach.id)) byFach.set(c.fach.id, [])
			byFach.get(c.fach.id).push(c)
		})
		const byEff = (a, b) => (b.eff ?? -1) - (a.eff ?? -1)
		byFach.forEach((list) => {
			const f = list[0].fach
			// LF und mündliche Prüfungsfächer: alle Kurse anrechnungspflichtig
			const must = isLF(f) || f.pruefung === 'm' ? list.length : Math.min(f.minAnr ?? list.length, list.length)
			const have = list.filter((c) => chosen.has(c)).length
			list.filter((c) => !chosen.has(c)).sort(byEff).slice(0, Math.max(0, must - have)).forEach((c) => chosen.add(c))
		})
		pool.filter((c) => !chosen.has(c)).sort(byEff).forEach((c) => {
			if (chosen.size < 40) chosen.add(c)
		})
		return chosen
	}

	function doubledSet(st, all) {
		const lfs = st.fachs.filter(isLF)
		if (st.settings.autoDouble !== false) {
			const sum = (id) => all.filter((c) => c.fach.id === id).reduce((a, c) => a + (c.eff ?? 0), 0)
			return new Set(lfs.map((f) => [f.id, sum(f.id)]).sort((a, b) => b[1] - a[1]).slice(0, 2).map((x) => x[0]))
		}
		return new Set(lfs.filter((f) => f.double).map((f) => f.id))
	}

	function blockI(st) {
		const all = allCourses(st)
		const known = all.filter((c) => c.pts != null)
		const overall = avg(known.map((c) => c.pts))
		const fachAvg = {}
		st.fachs.forEach((f) => {
			fachAvg[f.id] = avg(known.filter((c) => c.fach.id === f.id).map((c) => c.pts))
		})
		all.forEach((c) => {
			c.eff = c.pts ?? fachAvg[c.fach.id] ?? overall
			c.projected = c.pts == null
		})
		const chosen = selectCourses(all)
		const dbl = doubledSet(st, all)
		let sumP = 0
		let W = 0
		let nKnown = 0
		chosen.forEach((c) => {
			if (c.eff == null) return
			const w = dbl.has(c.fach.id) ? 2 : 1
			sumP += w * c.eff
			W += w
			if (!c.projected) nKnown++
		})
		const result = W ? roundHalfUp((sumP * 40) / W) : null
		const sel = [...chosen]
		const deficits = sel.filter((c) => c.pts != null && c.pts < 5)
		const lfDef = deficits.filter((c) => isLF(c.fach)).length
		const zero = all.filter((c) => c.pts === 0)
		const count = chosen.size
		const complete = count === 40 && nKnown === count
		const checks = []
		checks.push({ s: count === 40 ? 'ok' : 'warn', t: `${count} von 40 Kursen angerechnet${count < 40 ? ' – es fehlen belegte Kurse (Einrichtung prüfen)' : ''}` })
		checks.push({ s: nKnown === count ? 'ok' : 'info', t: `${nKnown} von ${count} angerechneten Kursen sind bewertet${nKnown < count ? ' – Rest ist hochgerechnet' : ''}` })
		checks.push({ s: zero.length ? 'fail' : 'ok', t: zero.length ? `Kurs mit 0 Punkten: ${zero.map((c) => c.fach.name + ' ' + HJ[c.hj]).join(', ')} – nicht zulässig` : 'Kein Kurs mit 0 Punkten' })
		checks.push({ s: deficits.length > 8 ? 'fail' : deficits.length > 6 ? 'warn' : 'ok', t: `${deficits.length} Kurs(e) unter 5 Punkten angerechnet (max. 8)` })
		checks.push({ s: lfDef > 3 ? 'fail' : lfDef > 2 ? 'warn' : 'ok', t: `${lfDef} davon in Leistungsfächern (max. 3)` })
		checks.push({ s: result == null ? 'info' : result >= 200 ? 'ok' : 'fail', t: `Block I mindestens 200 Punkte${result != null ? ' (aktuell ' + result + ')' : ''}` })
		return { all, chosen, dbl, result, W, count, nKnown, complete, checks }
	}

	// ---------- Block II ----------
	function pruefFaecher(st) {
		return st.fachs.filter(isLF).concat(st.fachs.filter((f) => !isLF(f) && f.pruefung === 'm'))
	}

	/** Gesamtergebnis eines Prüfungsfachs in Notenpunkten (0..15) oder null, wenn unvollständig. */
	function fachErgebnis(f, p) {
		p = p || {}
		const has = (x) => x != null
		let raw = null
		if (isLF(f)) {
			if (!has(p.s)) return null
			let s = p.s
			if (f.modernFS) {
				if (!has(p.k)) return null
				s = (2 * p.s + p.k) / 3
			} else if (f.praktisch) {
				if (!has(p.f)) return null
				s = (p.s + p.f) / 2
			}
			raw = has(p.m) ? (2 * s + p.m) / 3 : s
		} else {
			if (!has(p.m)) return null
			if (f.praktisch && has(p.f)) raw = (p.m + 2 * p.f) / 3
			else if (f.praktisch && f.name === 'Sport') return null // Sport: fachpraktisch Pflicht
			else raw = p.m
		}
		return clamp(roundHalfUp(raw))
	}

	function blockII(st, b1) {
		b1 = b1 || blockI(st)
		const rows = []
		let total = 0
		let complete = true
		pruefFaecher(st).forEach((f) => {
			let pts = fachErgebnis(f, st.pruefung[f.id])
			let est = false
			if (pts == null) {
				complete = false
				est = true
				const a = avg(b1.all.filter((c) => c.fach.id === f.id && c.pts != null).map((c) => c.pts))
				pts = a == null ? null : roundHalfUp(a)
			}
			const block = pts == null ? null : pts * 4
			if (block != null) total += block
			rows.push({ fach: f, pts, block, est })
		})
		const v = rows.filter((r) => r.block != null)
		const low = v.filter((r) => r.block < 4)
		const n20 = v.filter((r) => r.block >= 20).length
		const lf20 = v.filter((r) => isLF(r.fach) && r.block >= 20).length
		const pre = complete ? '' : ' (vorläufig)'
		const checks = [
			{ s: rows.length === 5 ? 'ok' : 'warn', t: `${rows.length} Prüfungsfächer gewählt (5 vorgeschrieben)` },
			{ s: total >= 100 ? 'ok' : 'fail', t: `Block II mindestens 100 Punkte – aktuell ${total}${pre}` },
			{ s: n20 >= 3 && lf20 >= 2 ? 'ok' : 'fail', t: `Mindestens 3 Prüfungsfächer mit je 20 Punkten (4×5), davon 2 Leistungsfächer – aktuell ${n20}, davon ${lf20} LF${pre}` },
			{ s: low.length ? 'fail' : 'ok', t: low.length ? `Unter 4 Punkten (weniger als 1 Notenpunkt): ${low.map((r) => r.fach.name).join(', ')}` : 'Kein Prüfungsfach unter 4 Punkten' },
		]
		return { rows, total, complete, checks }
	}

	// ---------- Note ----------
	function noteFromPoints(p) {
		if (p == null || p < 300) return null
		return Math.max(10, Math.floor((1020 - p) / 18)) / 10 // Abschneiden, nicht runden
	}
	function minPointsForNote(n) {
		return Math.max(300, 1020 - 18 * (Math.round(n * 10) + 1) + 1)
	}

	function gesamt(st) {
		const b1 = blockI(st)
		const b2 = blockII(st, b1)
		const total = b1.result == null ? null : b1.result + b2.total
		const note = noteFromPoints(total)
		const final = b1.complete && b2.complete
		const bad = b1.checks.concat(b2.checks).some((c) => c.s === 'fail')
		return { b1, b2, total, note, final, passed: !bad && total != null && total >= 300 }
	}

	// ---------- Plausibilitätsprüfung der Einrichtung ----------
	function setupChecks(st) {
		const c = []
		const lf = st.fachs.filter(isLF)
		const mu = st.fachs.filter((f) => !isLF(f) && f.pruefung === 'm')
		const pf = lf.concat(mu)
		c.push({ s: lf.length === 3 ? 'ok' : 'fail', t: `${lf.length} Leistungsfächer (3 vorgeschrieben)` })
		c.push({ s: mu.length === 2 ? 'ok' : 'warn', t: `${mu.length} mündliche Prüfungsfächer (2 üblich; alternativ 1 + Besondere Lernleistung)` })
		const has = (re) => pf.some((f) => re.test(f.name))
		c.push({ s: has(/^deutsch$/i) && has(/^mathematik$/i) ? 'ok' : 'fail', t: 'Deutsch und Mathematik sind schriftliches oder mündliches Prüfungsfach' })
		const areas = new Set(pf.map((f) => f.area))
		c.push({ s: [1, 2, 3].every((a) => areas.has(a)) ? 'ok' : 'fail', t: 'Die Prüfungsfächer decken alle drei Aufgabenfelder ab' })
		const core = lf.filter((f) => /^(deutsch|mathematik|biologie|chemie|physik)$/i.test(f.name) || f.modernFS || /^latein$/i.test(f.name))
		c.push({ s: core.length >= 2 ? 'ok' : 'warn', t: 'Mindestens 2 Leistungsfächer aus Deutsch, Mathematik, Fremdsprache, Naturwissenschaft' })
		const nGfs = st.fachs.filter((f) => f.gfs).length
		c.push({ s: nGfs >= 3 ? 'ok' : 'warn', t: `${nGfs} GFS in verschiedenen Fächern geplant (mindestens 3 verpflichtend, 4. optional)` })
		const belegt = st.fachs.reduce((a, f) => a + f.hjActive.filter(Boolean).length, 0)
		c.push({ s: belegt >= 42 ? 'ok' : 'warn', t: `${belegt} Kurse belegt (mindestens 42: 12 in Leistungsfächern + 30 weitere)` })
		const must = st.fachs.reduce((a, f) => {
			const n = f.hjActive.filter(Boolean).length
			return a + (isLF(f) || f.pruefung === 'm' ? n : Math.min(f.minAnr, n))
		}, 0)
		c.push({ s: must <= 40 ? 'ok' : 'fail', t: `${must} anrechnungspflichtige Kurse (höchstens 40 möglich)` })
		return c
	}

	return {
		HJ, NOTE, AREA, KATALOG, roundHalfUp, noteLabel, isLF, fmt, avg, uid,
		newFach, defaultState, migrate, hjResult, allCourses, blockI, blockII, gesamt,
		pruefFaecher, fachErgebnis, noteFromPoints, minPointsForNote, setupChecks,
	}
})
