<?php

declare(strict_types=1);

namespace OCA\AbiturPlaner\Controller;

use OCA\AbiturPlaner\AppInfo\Application;
use OCP\AppFramework\Controller;
use OCP\AppFramework\Http;
use OCP\AppFramework\Http\Attribute\NoAdminRequired;
use OCP\AppFramework\Http\JSONResponse;
use OCP\IConfig;
use OCP\IRequest;

/**
 * Speichert pro Nextcloud-Benutzer ein JSON-Dokument (Einstellungen, Noten, Prüfungen).
 * Die Berechnung passiert im Browser (js/calc.js).
 */
class DataController extends Controller {
	private const KEY = 'data';
	private const MAX_BYTES = 1000000;

	public function __construct(
		IRequest $request,
		private IConfig $config,
		private ?string $userId,
	) {
		parent::__construct(Application::APP_ID, $request);
	}

	#[NoAdminRequired]
	public function get(): JSONResponse {
		$raw = $this->config->getUserValue($this->userId, Application::APP_ID, self::KEY, '');
		return new JSONResponse(['data' => $raw === '' ? null : json_decode($raw, true)]);
	}

	#[NoAdminRequired]
	public function put(array $data): JSONResponse {
		$json = json_encode($data, JSON_UNESCAPED_UNICODE);
		if ($json === false || strlen($json) > self::MAX_BYTES) {
			return new JSONResponse(['error' => 'Daten zu groß oder ungültig'], Http::STATUS_BAD_REQUEST);
		}
		$this->config->setUserValue($this->userId, Application::APP_ID, self::KEY, $json);
		return new JSONResponse(['ok' => true]);
	}
}
