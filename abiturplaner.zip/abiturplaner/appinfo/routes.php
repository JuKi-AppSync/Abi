<?php

declare(strict_types=1);

return [
	'routes' => [
		['name' => 'page#index', 'url' => '/', 'verb' => 'GET'],
		['name' => 'data#get', 'url' => '/api/data', 'verb' => 'GET'],
		['name' => 'data#put', 'url' => '/api/data', 'verb' => 'PUT'],
	],
];
