<?php

use OCP\Util;

Util::addScript('abiturplaner', 'calc');
Util::addScript('abiturplaner', 'main');
Util::addStyle('abiturplaner', 'style');
?>
<div id="app-content">
	<div id="abiturplaner" class="abi">Lade Abiturplaner …</div>
</div>
