# Abiturplaner BW (Nextcloud-App)

Noten, GFS und Abiturpunkte der Kursstufe (Baden-Württemberg) pro Fach und Halbjahr eintragen.
Die App berechnet automatisch Halbjahresnoten, Block I, Block II, Gesamtpunkte und Abiturnote
und prüft Zulassungs- und Bestehensregeln. Die Daten liegen privat in deiner Nextcloud (pro Benutzer).

## Installation (Raspberry Pi, manuelle Nextcloud-Installation)

```bash
# 1. Ordner auf den Pi kopieren und entpacken (Ordnername muss "abiturplaner" sein)
sudo unzip abiturplaner.zip -d /var/www/nextcloud/custom_apps/

# 2. Rechte setzen (Webserver-Benutzer ist meist www-data)
sudo chown -R www-data:www-data /var/www/nextcloud/custom_apps/abiturplaner

# 3. App aktivieren
sudo -u www-data php /var/www/nextcloud/occ app:enable abiturplaner
```

Danach erscheint "Abiturplaner" in der oberen Nextcloud-Navigation.

Falls `custom_apps` nicht bekannt ist: in `config/config.php` muss unter `apps_paths` ein Eintrag
für `custom_apps` stehen (`'path' => OC::$SERVERROOT . '/custom_apps'`, `'url' => '/custom_apps'`, `'writable' => false`).

Falls die App wegen der Version nicht aktiviert werden lässt: Nextcloud-Version mit
`sudo -u www-data php occ status` prüfen und `min-version`/`max-version` in `appinfo/info.xml` anpassen.

## Update
Neue Dateien über die alten kopieren, Rechte setzen, ggf. `occ app:disable` + `occ app:enable`.
Deine Daten bleiben erhalten (Nextcloud-Benutzereinstellungen, Schlüssel `abiturplaner/data`).

## Umgesetzte Regeln (Kursstufe, aktuelle Abiturverordnung BW)
- Block I: genau 40 Kurse, 2 der 3 Leistungsfächer doppelt, Ergebnis = Punkte x 40 / 48 (max. 600, min. 200)
- Max. 8 Kurse unter 5 Punkten angerechnet, davon max. 3 in Leistungsfächern; kein belegungspflichtiger Kurs mit 0 Punkten
- Block II: 5 Prüfungen, je 4-fach (max. 300, min. 100); mind. 3 Fächer mit 20 Punkten (davon 2 LF); keine Prüfung unter 4 Punkten
- Prüfungsfach mit mündlichem Zusatz: (2 x schriftlich + mündlich) / 3
- Moderne Fremdsprache: (2 x schriftlich + Kommunikationsprüfung) / 3
- Fachpraktisch (BK/Mu/Sport): schriftlich 1:1 fachpraktisch; mündlich 1:2 (fachpraktisch doppelt)
- GFS zählt wie eine Klassenarbeit im schriftlichen Anteil
- Abiturnote: N = 17/3 - Punkte/180, auf eine Nachkommastelle abgeschnitten (823+ Punkte = 1,0; 300 = 4,0)

## Bekannte Näherungen / Grenzen
- Die Kurs-Auswahl für Block I ist eine automatische Optimierung (Pflichtkurse + beste übrige). Manuell überschreibbar pro Kurs.
- Besondere Lernleistung / Seminarkurs und die Kombiprüfung Geo/GK sind nicht abgebildet.
- Halbjahresnote = gewichtetes Mittel (schriftlich %/mündlich %) kaufmännisch gerundet. Die Lehrkraft entscheidet
  verbindlich – trage die Zeugnisnote im Dialog als "Halbjahresnote laut Zeugnis" ein.
- Zwischenrundungen bei Prüfungsergebnissen: kaufmännisch auf ganze Punkte.
- Für G9-Jahrgänge können sich Regeln noch ändern. Alle Parameter sind in der Einrichtung anpassbar.
- Alle Angaben ohne Gewähr; maßgeblich sind Schule und Kultusministerium.
